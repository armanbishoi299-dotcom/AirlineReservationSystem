PUT THE MYSQL JDBC DRIVER HERE
==============================
Download "MySQL Connector/J" (Platform Independent, ZIP) from
    https://dev.mysql.com/downloads/connector/j/
Unzip it and copy the file  mysql-connector-j-8.x.x.jar  into this folder.

It is only needed for MySQL mode (run.bat / run.sh).
Demo mode (run-demo.bat / run-demo.sh) works without it.
