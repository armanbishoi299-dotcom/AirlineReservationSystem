# Airline Reservation System

BCA minor project by **Arman Bishoi** (Roll No. 240845106029) · Guide: **Mr. Kamal Nain** · INMANTEC Group of Institutions, Ghaziabad.

A Java desktop application for searching flights, booking seats and managing reservations.
**Java Swing** (screens) + **JDBC** (connectivity) + **MySQL** (storage).

## Quick start (2 minutes, no database needed)

1. Install a JDK, Java 8 or newer.
2. Double-click **`run-demo.bat`** (Windows) or run **`./run-demo.sh`** (Linux / Mac).

Demo mode keeps the data in memory, so nothing is saved when you close the program. It uses exactly the same screens and rules as the MySQL version.

| Login | User name / email | Password |
|---|---|---|
| Passenger (pre-made) | `demo@airline.com` | `demo123` |
| Administrator | `admin` | `admin123` |

You can also click **Create account** to register a new passenger.

## Run with MySQL (the real project)

1. Install **MySQL Server** (8.x) and make sure it is running.
2. Download **MySQL Connector/J** (Platform Independent ZIP) from <https://dev.mysql.com/downloads/connector/j/> and copy `mysql-connector-j-8.x.x.jar` into the **`lib`** folder.
3. Open **`config/db.properties`** and set your MySQL user and password (`db.user`, `db.password`).
4. Double-click **`run.bat`** (Windows) or run **`./run.sh`** (Linux / Mac).

On the first start the program creates the database `airline_db`, the three tables and the sample flights by itself. If you prefer to do it by hand in MySQL Workbench, open and run `sql/schema.sql` and then `sql/sample_data.sql`.

If MySQL cannot be reached, the program says why and offers to open demo mode instead.

### Using an IDE (NetBeans / IntelliJ IDEA / Eclipse)

Create a new Java project, copy the `src` folder in as the source folder, add `lib/mysql-connector-j-*.jar` as a library, and run `airline.Main` (add the program argument `--demo` for demo mode). Start the program with the project folder as the working directory, so that `config/` and `sql/` are found.

## What the program does

**Passenger**
- Register (name, email, phone, password) with validation and duplicate-email check, then log in
- Search flights by source, destination and date (only flights with free seats are shown) or list all upcoming flights
- Book a flight: passenger name, age, gender → seat number assigned → **unique 8-character PNR**
- Payment: after the passenger details, pay by UPI, Card, Net Banking or Wallet (simulated gateway; test card 4111 1111 1111 1111, 4000 0000 0000 0002 is declined). Only the method, a masked reference and a transaction ID are stored - never the card number or CVV
- My bookings: history with status and payment; cancel by PNR (the seat is given back and a paid fare is marked Refunded)

**Administrator**
- Add, edit and delete flights (a flight that has bookings cannot be deleted)
- See every booking with passenger, PNR, flight and status, plus totals

## How it is built

```
Screens (Java Swing)      airline/ui/        LoginFrame, PassengerFrame, AdminFrame, dialogs
Business rules            airline/data/      Rules (validation, PNR, seat choice)
Data access (JDBC)        airline/data/      JdbcRepository + DBConnection  -> MySQL
Demo data source          airline/data/      MemoryRepository (same rules, no database)
Model classes             airline/model/     User, Flight, Booking
Database scripts          sql/               schema.sql, sample_data.sql
Settings                  config/            db.properties
```

- **`DBConnection`** is the single reusable JDBC connection class (URL, user and password come from `config/db.properties`).
- Every SQL statement uses **`PreparedStatement`**, so user input is never pasted into SQL.
- **Booking** and **cancellation** run in a JDBC **transaction**: the booking row and the seat count are saved together (`commit`) or not at all (`rollback`); the flight row is locked with `SELECT ... FOR UPDATE` so two users cannot take the last seat.
- Tables: `Users`, `Flights`, `Bookings`; `Bookings` holds foreign keys to `Users` and `Flights`; `email` and `pnr` are unique.
- The administrator account is read from `config/db.properties` (it is not a row of the `Users` table).

## Tests

```
test.bat            (or ./test.sh)          50 checks of the rules on the demo store
test.bat mysql      (or ./test.sh mysql)    the same 50 checks against your MySQL database
```

`test/airline/ui/GuiTest.java` opens the real windows, logs in, searches, books, cancels and uses the admin screens (17 checks) and saved the screenshots in `docs/screenshots`.

**Please run `test.bat mysql` once on your own computer before the evaluation.** It proves that the JDBC and MySQL part works with your installation.

## Known limits (be ready to say these in the viva)

- It is an academic simulation: no real airline inventory, no real tickets, and the payment gateway is simulated (no real money moves).
- Passwords are stored as plain text, as in the synopsis scope. Password hashing is listed as a future improvement.
- Dates are typed as `yyyy-MM-dd` (Swing has no built-in date picker).
- One administrator account, defined in `config/db.properties`.

## Troubleshooting

| Message | What to do |
|---|---|
| "The MySQL JDBC driver was not found" | Copy `mysql-connector-j-*.jar` into the `lib` folder |
| "Cannot connect to MySQL" / "Access denied" | Start the MySQL service; fix `db.user` / `db.password` in `config/db.properties` |
| `javac` is not recognised | Install a JDK (not only a JRE) and reopen the command window |
| Window opens but tables are empty | Run `sql/sample_data.sql`, or delete all rows of `Flights` and restart so the program re-inserts the sample flights |
