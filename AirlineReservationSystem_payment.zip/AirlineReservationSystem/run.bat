@echo off
rem Starts the program with MySQL (put mysql-connector-j-*.jar in the lib folder first)
cd /d "%~dp0"
if not exist out\airline\Main.class call build.bat
java -cp "out;lib/*" airline.Main %*
