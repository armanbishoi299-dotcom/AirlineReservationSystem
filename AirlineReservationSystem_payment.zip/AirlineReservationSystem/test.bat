@echo off
rem Runs the automated tests.   test.bat          -> demo store
rem                             test.bat mysql    -> your MySQL database (same checks)
cd /d "%~dp0"
if not exist test-out\airline\RepositoryTest.class call build.bat
java -cp "out;test-out;lib/*" airline.RepositoryTest %*
pause
