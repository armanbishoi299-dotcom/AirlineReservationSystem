package airline;

import airline.data.Config;
import airline.data.DBConnection;
import airline.data.JdbcRepository;
import airline.data.MemoryRepository;
import airline.data.Repository;
import airline.data.Rules;
import airline.model.Booking;
import airline.model.Flight;
import airline.model.Payment;
import airline.data.PaymentService;
import airline.model.User;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * Automated test of the business rules (registration, login, search, booking, cancellation, admin).
 *
 *   java -cp out;test-out airline.RepositoryTest            tests the in-memory demo store
 *   java -cp "out;test-out;lib/*" airline.RepositoryTest mysql    tests your real MySQL database
 *
 * The same checks run against both data sources, so a pass on "mysql" proves the JDBC code works.
 */
public final class RepositoryTest {
    private static int passed;
    private static int failed;

    private RepositoryTest() { }

    public static void main(String[] args) throws Exception {
        Repository repo;
        if (args.length > 0 && "mysql".equals(args[0])) {
            repo = new JdbcRepository(new DBConnection(Config.load("config/db.properties")));
            System.out.println("Testing against MySQL ...");
        } else {
            repo = new MemoryRepository();
            System.out.println("Testing against the in-memory demo store ...");
        }
        repo.init();
        run(repo);
        System.out.println();
        System.out.println(passed + " passed, " + failed + " failed");
        System.exit(failed == 0 ? 0 : 1);
    }

    private static void check(String name, boolean condition) {
        if (condition) {
            passed++;
            System.out.println("  PASS  " + name);
        } else {
            failed++;
            System.out.println("  FAIL  " + name);
        }
    }

    private static boolean fails(Action a, String messagePart) {
        try {
            a.run();
            return false;
        } catch (AirlineException e) {
            return e.getMessage().toLowerCase().contains(messagePart.toLowerCase());
        } catch (Exception e) {
            return false;
        }
    }

    private interface Action {
        void run() throws Exception;
    }

    private static void run(Repository repo) throws Exception {
        String tag = String.valueOf(System.currentTimeMillis() % 100000000L);
        String email = "student" + tag + "@example.com";

        System.out.println("Registration and login");
        User u = repo.register("Test Student", email, "pass1234", "9000000001");
        check("register creates a user with an id", u.getId() > 0);
        check("duplicate email is refused", fails(() -> repo.register("X", email.toUpperCase(), "pass1234",
                "9000000002"), "already exists"));
        check("empty name is refused", fails(() -> repo.register(" ", "a" + tag + "@e.com", "pass1234",
                "9000000003"), "Name is required"));
        check("bad email is refused", fails(() -> repo.register("N", "not-an-email", "pass1234", "9000000004"),
                "valid email"));
        check("short password is refused", fails(() -> repo.register("N", "b" + tag + "@e.com", "ab",
                "9000000005"), "Password"));
        check("bad phone is refused", fails(() -> repo.register("N", "c" + tag + "@e.com", "pass1234", "12"),
                "Phone"));
        check("login with correct password works", repo.login(email, "pass1234") != null);
        check("login ignores email capitals", repo.login(email.toUpperCase(), "pass1234") != null);
        check("login with wrong password fails", repo.login(email, "wrong") == null);
        check("login with unknown email fails", repo.login("nobody" + tag + "@e.com", "x") == null);

        System.out.println("Search");
        Flight admin = new Flight(0, "T" + tag.substring(0, Math.min(5, tag.length())), "Testville", "Sampleton",
                LocalDate.now().plusDays(5), LocalTime.of(9, 0), LocalTime.of(11, 0), 2, 2, 1500);
        Flight f = repo.addFlight(admin);
        check("admin can add a flight", f.getId() > 0 && f.getAvailableSeats() == 2);
        List<Flight> found = repo.searchFlights("testville", "SAMPLETON", f.getTravelDate());
        check("search finds the flight (any capitals)", found.size() == 1);
        check("search on another date finds nothing", repo.searchFlights("Testville", "Sampleton",
                f.getTravelDate().plusDays(1)).isEmpty());
        check("cities list includes the new city", repo.cities().contains("Testville"));
        check("upcoming list includes the flight", containsId(repo.upcomingFlights(), f.getId()));

        System.out.println("Booking");
        Booking b1 = repo.book(u.getId(), f.getId(), "Asha Rao", 25, "Female");
        check("booking returns an 8-character PNR", b1.getPnr() != null && b1.getPnr().length() == 8);
        check("first booking gets seat 1", b1.getSeatNumber() == 1);
        check("booking is Confirmed", Rules.CONFIRMED.equals(b1.getStatus()));
        check("booking reduces available seats", seatsOf(repo, f.getId()) == 1);
        Booking b2 = repo.book(u.getId(), f.getId(), "Ravi Rao", 30, "Male");
        check("second booking gets seat 2", b2.getSeatNumber() == 2);
        check("PNRs are different", !b1.getPnr().equals(b2.getPnr()));
        check("flight is full now", seatsOf(repo, f.getId()) == 0);
        check("full flight is not shown in search", repo.searchFlights("Testville", "Sampleton",
                f.getTravelDate()).isEmpty());
        check("booking a full flight is refused", fails(() -> repo.book(u.getId(), f.getId(), "Late Comer", 40,
                "Male"), "no seats"));
        check("invalid age is refused", fails(() -> repo.book(u.getId(), f.getId(), "Kid", 0, "Male"), "age"));
        check("my bookings lists both", repo.bookingsForUser(u.getId()).size() == 2);

        System.out.println("Cancellation");
        Booking c = repo.cancel(b1.getPnr().toLowerCase(), u.getId());
        check("cancel marks the booking Cancelled", Rules.CANCELLED.equals(c.getStatus()));
        check("cancel restores one seat", seatsOf(repo, f.getId()) == 1);
        check("cancelling twice is refused", fails(() -> repo.cancel(b1.getPnr(), u.getId()), "already cancelled"));
        check("wrong PNR is refused", fails(() -> repo.cancel("ZZZZZZZZ", u.getId()), "No booking"));
        User other = repo.register("Other Person", "o" + tag + "@example.com", "pass1234", "9000000009");
        check("another user cannot cancel my booking", fails(() -> repo.cancel(b2.getPnr(), other.getId()),
                "No booking"));
        Booking b3 = repo.book(other.getId(), f.getId(), "New Flyer", 22, "Other");
        check("freed seat 1 is reused", b3.getSeatNumber() == 1);

        System.out.println("Payment");
        Payment upi = PaymentService.payUpi("Asha@okbank");
        check("UPI payment succeeds with a transaction id", Payment.PAID.equals(upi.getStatus())
                && upi.getTransactionId().startsWith("TXN") && upi.getTransactionId().length() == 13);
        Payment card = PaymentService.payCard("Asha Rao", "4111 1111 1111 1111", "12/35", "123");
        check("card payment keeps only the last four digits", "xxxx 1111".equals(card.getReference()));
        check("invalid UPI id is refused", fails(() -> PaymentService.payUpi("not-an-id"), "UPI"));
        check("card number failing the Luhn check is refused", fails(() -> PaymentService.payCard("A", "4111111111111112",
                "12/35", "123"), "not valid"));
        check("expired card is refused", fails(() -> PaymentService.payCard("A", "4111111111111111", "01/20", "123"),
                "expired"));
        check("bad CVV is refused", fails(() -> PaymentService.payCard("A", "4111111111111111", "12/35", "12"), "CVV"));
        check("bank declines the test decline card", fails(() -> PaymentService.payCard("A", "4000000000000002",
                "12/35", "123"), "declined"));
        check("wallet needs a 10-digit mobile", fails(() -> PaymentService.payWallet("Paytm", "123"), "10 digits"));
        Flight pf = repo.addFlight(new Flight(0, "P" + tag.substring(0, Math.min(5, tag.length())), "Payville", "Sampleton",
                LocalDate.now().plusDays(6), LocalTime.of(9, 0), LocalTime.of(11, 0), 3, 3, 1800));
        Booking paid = repo.book(other.getId(), pf.getId(), "Paid Flyer", 33, "Male", card);
        check("booking stores the payment details", Payment.PAID.equals(paid.getPaymentStatus())
                && "Card".equals(paid.getPaymentMethod()) && card.getTransactionId().equals(paid.getTransactionId()));
        Booking unpaid = repo.book(other.getId(), pf.getId(), "Plain Flyer", 40, "Male");
        check("booking without a payment step is Unpaid", Payment.UNPAID.equals(unpaid.getPaymentStatus()));
        check("cancelling a paid booking marks it Refunded", Payment.REFUNDED.equals(
                repo.cancel(paid.getPnr(), other.getId()).getPaymentStatus()));
        check("cancelling an unpaid booking leaves it Unpaid", Payment.UNPAID.equals(
                repo.cancel(unpaid.getPnr(), other.getId()).getPaymentStatus()));

        System.out.println("Administrator");
        check("all bookings include the new ones", repo.allBookings().size() >= 3);
        Flight edit = f.copy();
        edit.setPrice(1750);
        edit.setTotalSeats(5);
        repo.updateFlight(edit);
        check("edit changes seats and keeps booked seats counted", seatsOf(repo, f.getId()) == 3);
        Flight tooSmall = f.copy();
        tooSmall.setTotalSeats(1);
        check("cannot shrink below booked seats", fails(() -> repo.updateFlight(tooSmall), "already booked"));
        check("flight with bookings cannot be deleted", fails(() -> repo.deleteFlight(f.getId()), "bookings"));
        Flight empty = repo.addFlight(new Flight(0, "E" + tag.substring(0, Math.min(5, tag.length())), "Emptyton",
                "Nowhere", LocalDate.now().plusDays(6), LocalTime.of(7, 0), LocalTime.of(8, 0), 10, 10, 900));
        repo.deleteFlight(empty.getId());
        check("flight without bookings can be deleted", !containsId(repo.allFlights(), empty.getId()));
        check("same source and destination is refused", fails(() -> repo.addFlight(new Flight(0, "S1", "Delhi",
                "delhi", LocalDate.now().plusDays(2), LocalTime.of(7, 0), LocalTime.of(8, 0), 10, 10, 900)),
                "different"));
    }

    private static boolean containsId(List<Flight> list, int id) {
        for (Flight f : list) {
            if (f.getId() == id) {
                return true;
            }
        }
        return false;
    }

    private static int seatsOf(Repository repo, int flightId) throws AirlineException {
        for (Flight f : repo.allFlights()) {
            if (f.getId() == flightId) {
                return f.getAvailableSeats();
            }
        }
        return -1;
    }
}
