package airline.ui;

import airline.data.Config;
import airline.data.MemoryRepository;
import airline.data.Repository;
import airline.data.Rules;

import javax.imageio.ImageIO;
import javax.swing.AbstractButton;
import javax.swing.JDialog;
import javax.swing.SwingUtilities;
import java.awt.Component;
import java.awt.Container;
import java.awt.Window;
import java.awt.image.BufferedImage;
import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Drives the real windows (login, passenger, administrator) like a user would, checks the results
 * and saves screenshots to docs/screenshots. Needs a display (on a server run it under xvfb-run).
 *
 *   java -cp out;test-out airline.ui.GuiTest [--shots]
 */
public final class GuiTest {
    private static int passed;
    private static int failed;
    private static boolean shots;
    private static final File DIR = new File("docs/screenshots");
    private static volatile boolean helperRunning = true;
    private static volatile String dialogShotName;
    private static final java.util.Set<Window> handled =
            java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<>());

    private GuiTest() { }

    private static void check(String name, boolean ok) {
        if (ok) {
            passed++;
            System.out.println("  PASS  " + name);
        } else {
            failed++;
            System.out.println("  FAIL  " + name);
        }
    }

    public static void main(String[] args) throws Exception {
        shots = args.length > 0 && "--shots".equals(args[0]);
        if (shots) {
            DIR.mkdirs();
        }
        Repository repo = new MemoryRepository();
        repo.init();
        Config config = Config.defaults();
        startDialogHelper(repo);

        // ---------------------------------------------------------------- login screen
        LoginFrame login = onEdt(() -> {
            LoginFrame f = new LoginFrame(repo, config);
            f.setVisible(true);
            return f;
        });
        shoot(login, "01_login");
        onEdt(() -> {
            login.showCard("register");
            return null;
        });
        shoot(login, "02_register");

        System.out.println("Login screen");
        onEdt(() -> {
            login.regName.setText("Arman Bishoi");
            login.regEmail.setText("arman@example.com");
            login.regPhone.setText("9811122233");
            login.regPassword.setText("secret1");
            login.regConfirm.setText("secret1");
            login.doRegister();
            return null;
        });
        check("registering fills the login form with the new email", "arman@example.com".equals(onEdt(
                () -> login.loginId.getText())));
        check("registering shows a success message", onEdt(() -> login.loginMessage.getText())
                .startsWith("Account created"));
        onEdt(() -> {
            login.loginPassword.setText("wrong");
            login.doLogin();
            return null;
        });
        check("wrong password shows an error and stays on login", onEdt(() -> login.loginMessage.getText())
                .startsWith("Wrong email") && onEdt(login::isVisible));
        shoot(login, "03_login_error");

        // ------------------------------------------------------------- passenger window
        onEdt(() -> {
            login.loginId.setText("demo@airline.com");
            login.loginPassword.setText("demo123");
            login.doLogin();
            return null;
        });
        PassengerFrame pf = waitFor(PassengerFrame.class);
        System.out.println("Passenger window");
        check("passenger window opens after login", pf != null);
        check("upcoming flights are listed at start", onEdt(() -> pf.flightModel.getRowCount()) >= 10);
        shoot(pf, "04_passenger_flights");

        String tomorrow = LocalDate.now().plusDays(1).format(Rules.DATE_FMT);
        onEdt(() -> {
            pf.fromBox.setSelectedItem("Delhi");
            pf.toBox.setSelectedItem("Mumbai");
            pf.dateField.setText(tomorrow);
            pf.search();
            return null;
        });
        check("search Delhi to Mumbai tomorrow finds 2 flights", onEdt(() -> pf.flightModel.getRowCount()) == 2);
        shoot(pf, "05_passenger_search");

        dialogShotName = "06_booking_dialog";
        onEdt(() -> {
            pf.flightTable.setRowSelectionInterval(0, 0);
            return null;
        });
        runBlocking(pf::bookSelected);
        check("booking through the dialog adds a row to My bookings", onEdt(() -> pf.bookingModel.getRowCount()) == 1);
        String pnr = onEdt(() -> String.valueOf(pf.bookingModel.getValueAt(0, 0)));
        check("the PNR is 8 characters", pnr.length() == 8);
        check("booking is Confirmed", "Confirmed".equals(onEdt(() -> pf.bookingModel.getValueAt(0, 7))));
        check("booking shows the card payment as Paid", "Card - Paid".equals(onEdt(
                () -> String.valueOf(pf.bookingModel.getValueAt(0, 8)))));
        check("seats left dropped to 59 after booking", Integer.valueOf(59).equals(onEdt(
                () -> pf.flightModel.getValueAt(0, 6))));
        onEdt(() -> {
            pf.tabs.setSelectedIndex(1);
            return null;
        });
        shoot(pf, "07_my_bookings");

        onEdt(() -> {
            pf.bookingTable.setRowSelectionInterval(0, 0);
            return null;
        });
        check("selecting a booking fills the PNR box", pnr.equals(onEdt(() -> pf.pnrField.getText())));
        dialogShotName = "08_cancel_confirm";
        runBlocking(pf::cancelBooking);
        check("cancel changes the status to Cancelled", "Cancelled".equals(onEdt(
                () -> pf.bookingModel.getValueAt(0, 7))));
        shoot(pf, "09_booking_cancelled");

        // ---------------------------------------------------------------- admin window
        onEdt(() -> {
            find(pf, "Logout").doClick();
            return null;
        });
        LoginFrame login2 = waitFor(LoginFrame.class);
        check("logout returns to the login screen", login2 != null);
        onEdt(() -> {
            login2.adminRadio.doClick();
            login2.loginId.setText("admin");
            login2.loginPassword.setText("admin123");
            login2.doLogin();
            return null;
        });
        AdminFrame af = waitFor(AdminFrame.class);
        System.out.println("Administrator window");
        check("administrator window opens", af != null);
        int before = onEdt(() -> af.flightModel.getRowCount());
        shoot(af, "10_admin_flights");
        dialogShotName = "11_admin_add_flight";
        runBlocking(af::addFlight);
        check("adding a flight increases the table by one", onEdt(() -> af.flightModel.getRowCount()) == before + 1);
        onEdt(() -> {
            af.tabs.setSelectedIndex(1);
            return null;
        });
        shoot(af, "12_admin_bookings");
        check("all-bookings tab shows the cancelled booking", onEdt(() -> af.bookingModel.getRowCount()) == 1
                && "Cancelled".equals(onEdt(() -> af.bookingModel.getValueAt(0, 10))));

        helperRunning = false;
        System.out.println();
        System.out.println(passed + " passed, " + failed + " failed");
        System.exit(failed == 0 ? 0 : 1);
    }

    // ------------------------------------------------------------------ helpers

    private interface Task<T> {
        T run() throws Exception;
    }

    private static <T> T onEdt(Task<T> task) throws Exception {
        final Object[] box = new Object[1];
        final Exception[] err = new Exception[1];
        SwingUtilities.invokeAndWait(() -> {
            try {
                box[0] = task.run();
            } catch (Exception e) {
                err[0] = e;
            }
        });
        if (err[0] != null) {
            throw err[0];
        }
        @SuppressWarnings("unchecked")
        T value = (T) box[0];
        return value;
    }

    /** Runs code that opens modal dialogs; the background helper closes them. */
    private static void runBlocking(Runnable r) throws Exception {
        SwingUtilities.invokeAndWait(r);
    }

    @SuppressWarnings("unchecked")
    private static <T extends Window> T waitFor(Class<T> type) throws Exception {
        for (int i = 0; i < 60; i++) {
            for (Window w : Window.getWindows()) {
                if (type.isInstance(w) && w.isShowing()) {
                    return (T) w;
                }
            }
            Thread.sleep(100);
        }
        return null;
    }

    private static void shoot(Window w, String name) throws Exception {
        if (!shots) {
            return;
        }
        Thread.sleep(250);
        onEdt(() -> {
            save(w, name);
            return null;
        });
    }

    private static void save(Window w, String name) {
        try {
            BufferedImage img = new BufferedImage(w.getWidth(), w.getHeight(), BufferedImage.TYPE_INT_RGB);
            java.awt.Graphics2D g = img.createGraphics();
            w.paint(g);
            g.dispose();
            ImageIO.write(img, "png", new File(DIR, name + ".png"));
        } catch (Exception e) {
            System.out.println("  (could not save " + name + ": " + e + ")");
        }
    }

    /** Watches for dialogs: fills in the booking / flight forms and presses Yes / OK. */
    private static void startDialogHelper(Repository repo) {
        Thread t = new Thread(() -> {
            while (helperRunning) {
                try {
                    Thread.sleep(200);
                    List<Window> windows = new ArrayList<>();
                    for (Window w : Window.getWindows()) {
                        if (w instanceof JDialog && w.isShowing()) {
                            windows.add(w);
                        }
                    }
                    for (Window w : windows) {
                        if (handled.add(w)) {
                            handle((JDialog) w);
                        }
                    }
                } catch (Exception ignored) {
                    // keep watching
                }
            }
        }, "dialog-helper");
        t.setDaemon(true);
        t.start();
    }

    private static void handle(JDialog d) throws Exception {
        if (d instanceof BookingDialog) {
            BookingDialog b = (BookingDialog) d;
            SwingUtilities.invokeAndWait(() -> b.ageField.setText("28"));
            snap(d);
            dialogShotName = "13_payment_dialog";
            SwingUtilities.invokeLater(b::confirmBooking); // opens the modal payment dialog, handled on the next poll
        } else if (d instanceof PaymentDialog) {
            PaymentDialog p = (PaymentDialog) d;
            SwingUtilities.invokeAndWait(() -> {
                p.select("Card");
                p.cardName.setText("Demo Passenger");
                p.cardNumber.setText("4111 1111 1111 1111");
                p.cardExpiry.setText("12/35");
                p.cardCvv.setText("123");
            });
            snap(d);
            SwingUtilities.invokeAndWait(p::pay);
        } else if (d instanceof FlightDialog) {
            FlightDialog f = (FlightDialog) d;
            SwingUtilities.invokeAndWait(() -> {
                f.number.setText("ar999");
                f.source.setText("Pune");
                f.destination.setText("Jaipur");
                f.fare.setText("3900");
            });
            snap(d);
            SwingUtilities.invokeAndWait(f::save);
        } else {
            snap(d);
            AbstractButton yes = find(d, "Yes");
            if (yes == null) {
                yes = find(d, "OK");
            }
            if (yes != null) {
                final AbstractButton click = yes;
                SwingUtilities.invokeAndWait(click::doClick);
            }
        }
    }

    private static void snap(JDialog d) throws Exception {
        String name = dialogShotName;
        if (shots && name != null) {
            dialogShotName = null;
            Thread.sleep(250);
            SwingUtilities.invokeAndWait(() -> save(d, name));
        }
    }

    private static AbstractButton find(Container c, String text) {
        for (Component child : c.getComponents()) {
            if (child instanceof AbstractButton && text.equals(((AbstractButton) child).getText())) {
                return (AbstractButton) child;
            }
            if (child instanceof Container) {
                AbstractButton r = find((Container) child, text);
                if (r != null) {
                    return r;
                }
            }
        }
        return null;
    }
}
