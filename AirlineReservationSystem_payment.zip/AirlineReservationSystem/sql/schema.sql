-- ============================================================
--  Airline Reservation System  -  MySQL schema
--  Tables: Users, Flights, Bookings
--  Run in MySQL Workbench, or let the application create it
--  automatically the first time it starts.
-- ============================================================

CREATE DATABASE IF NOT EXISTS airline_db;
USE airline_db;

CREATE TABLE IF NOT EXISTS Users (
    user_id   INT          NOT NULL AUTO_INCREMENT,
    name      VARCHAR(100) NOT NULL,
    email     VARCHAR(100) NOT NULL,
    password  VARCHAR(100) NOT NULL,
    phone     VARCHAR(15),
    PRIMARY KEY (user_id),
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Flights (
    flight_id       INT           NOT NULL AUTO_INCREMENT,
    flight_number   VARCHAR(20)   NOT NULL,
    source          VARCHAR(50)   NOT NULL,
    destination     VARCHAR(50)   NOT NULL,
    travel_date     DATE          NOT NULL,
    departure_time  TIME          NOT NULL,
    arrival_time    TIME          NOT NULL,
    total_seats     INT           NOT NULL,
    available_seats INT           NOT NULL,
    price           DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (flight_id),
    CONSTRAINT chk_seats CHECK (available_seats >= 0 AND available_seats <= total_seats)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Bookings (
    booking_id       INT         NOT NULL AUTO_INCREMENT,
    pnr              VARCHAR(12) NOT NULL,
    user_id          INT         NOT NULL,
    flight_id        INT         NOT NULL,
    passenger_name   VARCHAR(100) NOT NULL,
    passenger_age    INT         NOT NULL,
    passenger_gender VARCHAR(10) NOT NULL,
    seat_number      INT         NOT NULL,
    booking_date     DATE        NOT NULL,
    status           VARCHAR(20) NOT NULL,
    payment_method   VARCHAR(20),
    payment_ref      VARCHAR(60),
    txn_id           VARCHAR(20),
    payment_status   VARCHAR(12) NOT NULL DEFAULT 'Unpaid',
    PRIMARY KEY (booking_id),
    UNIQUE KEY uq_bookings_pnr (pnr),
    CONSTRAINT fk_bookings_user   FOREIGN KEY (user_id)   REFERENCES Users(user_id),
    CONSTRAINT fk_bookings_flight FOREIGN KEY (flight_id) REFERENCES Flights(flight_id)
) ENGINE=InnoDB;
