-- ============================================================
--  Sample data for the demonstration
--  (the application inserts the same data automatically when the
--   Flights table is empty; run this file only if you want to load
--   it by hand in MySQL Workbench)
-- ============================================================

USE airline_db;

-- Demo passenger: demo@airline.com / demo123
INSERT INTO Users (name, email, password, phone)
SELECT 'Demo Passenger', 'demo@airline.com', 'demo123', '9876543210'
WHERE NOT EXISTS (SELECT 1 FROM Users WHERE email = 'demo@airline.com');

-- Flights on the next few days (dates are relative to today)
INSERT INTO Flights (flight_number, source, destination, travel_date, departure_time, arrival_time, total_seats, available_seats, price) VALUES
('AR101', 'Delhi',     'Mumbai',    CURDATE() + INTERVAL 1 DAY, '06:00', '08:10', 60, 60, 4850),
('AR102', 'Delhi',     'Mumbai',    CURDATE() + INTERVAL 1 DAY, '13:30', '15:40', 60, 60, 5400),
('AR103', 'Mumbai',    'Delhi',     CURDATE() + INTERVAL 1 DAY, '09:15', '11:25', 60, 60, 4950),
('AR201', 'Delhi',     'Bengaluru', CURDATE() + INTERVAL 1 DAY, '07:45', '10:30', 80, 80, 6200),
('AR202', 'Bengaluru', 'Delhi',     CURDATE() + INTERVAL 2 DAY, '18:20', '21:05', 80, 80, 6350),
('AR301', 'Delhi',     'Kolkata',   CURDATE() + INTERVAL 2 DAY, '10:00', '12:15', 50, 50, 5100),
('AR302', 'Kolkata',   'Delhi',     CURDATE() + INTERVAL 3 DAY, '16:40', '18:55', 50, 50, 5250),
('AR401', 'Mumbai',    'Chennai',   CURDATE() + INTERVAL 1 DAY, '11:10', '13:05', 70, 70, 4300),
('AR402', 'Chennai',   'Mumbai',    CURDATE() + INTERVAL 2 DAY, '15:25', '17:20', 70, 70, 4400),
('AR501', 'Delhi',     'Hyderabad', CURDATE() + INTERVAL 2 DAY, '08:30', '10:55', 60, 60, 5600),
('AR502', 'Hyderabad', 'Delhi',     CURDATE() + INTERVAL 3 DAY, '20:00', '22:25', 60, 60, 5700),
('AR601', 'Mumbai',    'Goa',       CURDATE() + INTERVAL 3 DAY, '12:00', '13:10', 40, 40, 3200);
