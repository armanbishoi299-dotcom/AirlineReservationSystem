@echo off
rem Compiles the program (needs a JDK, Java 8 or newer)
cd /d "%~dp0"
if exist out rmdir /s /q out
if exist test-out rmdir /s /q test-out
mkdir out
mkdir test-out
dir /s /b src\*.java > sources.txt
dir /s /b test\*.java > test-sources.txt
javac --release 8 -Xlint:-options -d out @sources.txt
if errorlevel 1 goto fail
javac --release 8 -Xlint:-options -cp out -d test-out @test-sources.txt
if errorlevel 1 goto fail
del sources.txt test-sources.txt
echo Build finished.
goto end
:fail
echo Build FAILED.
:end
