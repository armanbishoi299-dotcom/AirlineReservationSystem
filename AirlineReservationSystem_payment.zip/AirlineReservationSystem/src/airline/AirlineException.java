package airline;

/**
 * A problem that can be shown to the user as a plain message
 * (validation error, "no seats left", database not reachable, ...).
 */
public class AirlineException extends Exception {
    private static final long serialVersionUID = 1L;

    public AirlineException(String message) {
        super(message);
    }

    public AirlineException(String message, Throwable cause) {
        super(message, cause);
    }
}
