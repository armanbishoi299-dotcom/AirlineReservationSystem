package airline.model;

import java.time.LocalDate;

/**
 * A reservation (row of the Bookings table) together with the flight and user
 * details that are needed to display it.
 */
public class Booking {
    private int id;
    private String pnr;
    private int userId;
    private int flightId;
    private String passengerName;
    private int passengerAge;
    private String passengerGender;
    private int seatNumber;
    private LocalDate bookingDate;
    private String status;

    // joined, display-only values
    private String flightNumber;
    private String source;
    private String destination;
    private LocalDate travelDate;
    private double price;
    private String userEmail;
    private String paymentMethod;
    private String paymentRef;
    private String transactionId;
    private String paymentStatus = Payment.UNPAID;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getPnr() { return pnr; }
    public void setPnr(String pnr) { this.pnr = pnr; }
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public int getFlightId() { return flightId; }
    public void setFlightId(int flightId) { this.flightId = flightId; }
    public String getPassengerName() { return passengerName; }
    public void setPassengerName(String passengerName) { this.passengerName = passengerName; }
    public int getPassengerAge() { return passengerAge; }
    public void setPassengerAge(int passengerAge) { this.passengerAge = passengerAge; }
    public String getPassengerGender() { return passengerGender; }
    public void setPassengerGender(String passengerGender) { this.passengerGender = passengerGender; }
    public int getSeatNumber() { return seatNumber; }
    public void setSeatNumber(int seatNumber) { this.seatNumber = seatNumber; }
    public LocalDate getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDate bookingDate) { this.bookingDate = bookingDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getFlightNumber() { return flightNumber; }
    public void setFlightNumber(String flightNumber) { this.flightNumber = flightNumber; }
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public LocalDate getTravelDate() { return travelDate; }
    public void setTravelDate(LocalDate travelDate) { this.travelDate = travelDate; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }
    public String getPaymentRef() { return paymentRef; }
    public void setPaymentRef(String paymentRef) { this.paymentRef = paymentRef; }
    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }
    public String getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }

    /** Short text for tables, e.g. "UPI - Paid" or "Card - Refunded". */
    public String getPaymentSummary() {
        if (paymentMethod == null) {
            return paymentStatus;
        }
        return paymentMethod + " - " + paymentStatus;
    }

    public String getRoute() { return source + " to " + destination; }
}
