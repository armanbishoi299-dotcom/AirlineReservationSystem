package airline.model;

/**
 * The outcome of a (simulated) payment for one booking.
 * Only safe details are kept: the method, a masked reference such as "xxxx 1111"
 * or a UPI id, and the transaction id. Card numbers and CVV codes are never stored.
 */
public class Payment {
    public static final String UPI = "UPI";
    public static final String CARD = "Card";
    public static final String NET_BANKING = "Net Banking";
    public static final String WALLET = "Wallet";

    public static final String PAID = "Paid";
    public static final String REFUNDED = "Refunded";
    public static final String UNPAID = "Unpaid";

    private final String method;
    private final String reference;
    private final String transactionId;
    private final String status;

    public Payment(String method, String reference, String transactionId, String status) {
        this.method = method;
        this.reference = reference;
        this.transactionId = transactionId;
        this.status = status;
    }

    /** Used by callers (and old tests) that book without a payment step. */
    public static Payment unpaid() {
        return new Payment(null, null, null, UNPAID);
    }

    public String getMethod() { return method; }
    public String getReference() { return reference; }
    public String getTransactionId() { return transactionId; }
    public String getStatus() { return status; }
}
