package airline;

import airline.data.Config;
import airline.data.DBConnection;
import airline.data.JdbcRepository;
import airline.data.MemoryRepository;
import airline.data.Repository;
import airline.ui.LoginFrame;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Starts the Airline Reservation System.
 *
 *   java -cp "out;lib/*" airline.Main            normal mode: MySQL through JDBC
 *   java -cp "out;lib/*" airline.Main --demo     demo mode: no database needed (data kept in memory)
 */
public final class Main {
    private Main() { }

    public static void main(String[] args) {
        boolean demo = false;
        String configPath = "config/db.properties";
        for (int i = 0; i < args.length; i++) {
            if ("--demo".equals(args[i])) {
                demo = true;
            } else if ("--config".equals(args[i]) && i + 1 < args.length) {
                configPath = args[++i];
            }
        }
        final boolean demoMode = demo;
        final Config config = Config.load(configPath);

        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
                // the default look and feel is fine
            }
            Repository repo = demoMode ? new MemoryRepository() : new JdbcRepository(new DBConnection(config));
            try {
                repo.init();
            } catch (AirlineException ex) {
                int choice = JOptionPane.showOptionDialog(null,
                        ex.getMessage() + "\n\nDo you want to open the program in DEMO MODE instead\n"
                                + "(no database needed, data is not saved)?",
                        "Airline Reservation System - database problem", JOptionPane.YES_NO_OPTION,
                        JOptionPane.ERROR_MESSAGE, null, new Object[] {"Open demo mode", "Exit"}, "Exit");
                if (choice != 0) {
                    System.exit(1);
                    return;
                }
                repo = new MemoryRepository();
                try {
                    repo.init();
                } catch (AirlineException impossible) {
                    System.exit(1);
                    return;
                }
            }
            new LoginFrame(repo, config).setVisible(true);
        });
    }
}
