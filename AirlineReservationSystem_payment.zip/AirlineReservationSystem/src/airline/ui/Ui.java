package airline.ui;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JTabbedPane;
import javax.swing.JScrollBar;
import javax.swing.UIManager;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import javax.swing.border.AbstractBorder;
import java.awt.GradientPaint;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JViewport;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Locale;

/** Colours, fonts and small helpers that give every screen the same look. */
final class Ui {
    static final Color NAVY = new Color(0x0E1B33);
    static final Color MID = new Color(0x16305E);
    static final Color BLUE = new Color(0x1F6FDE);
    static final Color AMBER = new Color(0xF2B134);
    static final Color BG = new Color(0xF1F4FA);
    static final Color INK = new Color(0x1B2740);
    static final Color MUTED = new Color(0x55617A);
    static final Color LINE = new Color(0xD5DDEC);
    static final Color PALE = new Color(0xE6ECF7);
    static final Color GREEN = new Color(0x1E7B4B);
    static final Color RED = new Color(0xB3261E);

    private Ui() { }

    static {
        UIManager.put("OptionPane.messageFont", font(Font.PLAIN, 14));
        UIManager.put("OptionPane.buttonFont", font(Font.BOLD, 13));
        UIManager.put("OptionPane.messageForeground", INK);
        UIManager.put("OptionPane.background", Color.WHITE);
        UIManager.put("Panel.background", Color.WHITE);
        UIManager.put("ToolTip.font", font(Font.PLAIN, 12));
    }

    static void aa(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    }

    static Font font(int style, int size) {
        return new Font(Font.SANS_SERIF, style, size);
    }

    static String money(double amount) {
        return String.format(Locale.ENGLISH, "Rs. %,.0f", amount);
    }

    // ----------------------------------------------------------- components

    static JLabel label(String text, int style, int size, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font(style, size));
        l.setForeground(color);
        return l;
    }

    static JLabel fieldLabel(String text) {
        return label(text, Font.BOLD, 13, MUTED);
    }

    static JTextField field(int columns) {
        JTextField f = new JTextField(columns) {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                paintRoundBg(g, this);
                super.paintComponent(g);
            }
        };
        styleField(f);
        return f;
    }

    static JPasswordField password(int columns) {
        JPasswordField f = new JPasswordField(columns) {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                paintRoundBg(g, this);
                super.paintComponent(g);
            }
        };
        styleField(f);
        return f;
    }

    static void paintRoundBg(Graphics g, JComponent c) {
        Graphics2D g2 = (Graphics2D) g.create();
        aa(g2);
        g2.setColor(Color.WHITE);
        g2.fill(new RoundRectangle2D.Double(1, 1, c.getWidth() - 2, c.getHeight() - 2, 10, 10));
        g2.dispose();
    }

    private static void styleField(javax.swing.text.JTextComponent f) {
        f.setFont(font(Font.PLAIN, 14));
        f.setOpaque(false);
        f.setForeground(INK);
        f.setCaretColor(BLUE);
        f.setSelectionColor(new Color(0xCFE0FA));
        f.setPreferredSize(new Dimension(f.getPreferredSize().width, 36));
        f.setBorder(new RoundBorder(false));
        f.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                f.repaint();
            }

            @Override
            public void focusLost(FocusEvent e) {
                f.repaint();
            }
        });
    }

    /** Styles a combo box to match the text fields. */
    static <T> JComboBox<T> combo(JComboBox<T> box) {
        box.setFont(font(Font.PLAIN, 14));
        box.setBackground(Color.WHITE);
        box.setForeground(INK);
        box.setBorder(new RoundBorder(false));
        box.setUI(new BasicComboBoxUI() {
            @Override
            protected javax.swing.JButton createArrowButton() {
                javax.swing.JButton b = new javax.swing.JButton() {
                    private static final long serialVersionUID = 1L;

                    @Override
                    protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        aa(g2);
                        g2.setColor(MUTED);
                        int cx = getWidth() / 2;
                        int cy = getHeight() / 2;
                        Path2D p = new Path2D.Double();
                        p.moveTo(cx - 4, cy - 2);
                        p.lineTo(cx, cy + 2);
                        p.lineTo(cx + 4, cy - 2);
                        g2.setStroke(new java.awt.BasicStroke(1.8f, java.awt.BasicStroke.CAP_ROUND,
                                java.awt.BasicStroke.JOIN_ROUND));
                        g2.draw(p);
                        g2.dispose();
                    }
                };
                b.setBorder(BorderFactory.createEmptyBorder());
                b.setContentAreaFilled(false);
                b.setFocusPainted(false);
                return b;
            }

            @Override
            public void paintCurrentValueBackground(Graphics g, Rectangle bounds, boolean hasFocus) {
                g.setColor(Color.WHITE);
                g.fillRect(bounds.x, bounds.y, bounds.width, bounds.height);
            }
        });
        if (box.getEditor() != null && box.getEditor().getEditorComponent() instanceof JComponent) {
            ((JComponent) box.getEditor().getEditorComponent()).setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 4));
            ((JComponent) box.getEditor().getEditorComponent()).setOpaque(false);
        }
        return box;
    }

    /** Pill-shaped coloured label (used for statuses). */
    static JLabel pill(String text, Color fg, Color bg) {
        JLabel l = new JLabel(text, SwingConstants.CENTER) {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                aa(g2);
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        l.setOpaque(false);
        l.setFont(font(Font.BOLD, 12));
        l.setForeground(fg);
        l.setBorder(BorderFactory.createEmptyBorder(3, 12, 3, 12));
        return l;
    }

    /** Rounded border with a blue ring while the field has focus. */
    static final class RoundBorder extends AbstractBorder {
        private static final long serialVersionUID = 1L;
        private final boolean thin;

        RoundBorder(boolean thin) {
            this.thin = thin;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            boolean focus = c.hasFocus() || (c instanceof JComboBox && ((JComboBox<?>) c).getEditor() != null
                    && ((JComboBox<?>) c).getEditor().getEditorComponent().hasFocus());
            g2.setColor(focus ? BLUE : LINE);
            g2.setStroke(new java.awt.BasicStroke(focus ? 2f : 1f));
            g2.draw(new RoundRectangle2D.Double(x + 1, y + 1, w - 2, h - 2, 10, 10));
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(thin ? 2 : 4, 12, thin ? 2 : 4, 12);
        }

        @Override
        public boolean isBorderOpaque() {
            return false;
        }
    }

    static AppButton button(String text, Color background) {
        return new AppButton(text, background);
    }

    static JPanel card() {
        JPanel p = new JPanel() {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                aa(g2);
                for (int i = 4; i >= 1; i--) {
                    g2.setColor(new Color(20, 40, 90, 6 + (4 - i) * 2));
                    g2.fill(new RoundRectangle2D.Double(4 - i, 5 - i, getWidth() - 8 + 2 * i, getHeight() - 8 + 2 * i,
                            18 + i, 18 + i));
                }
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Double(4, 3, getWidth() - 8, getHeight() - 8, 16, 16));
                g2.setColor(new Color(0xE3E9F4));
                g2.draw(new RoundRectangle2D.Double(4.5, 3.5, getWidth() - 9, getHeight() - 9, 16, 16));
                g2.dispose();
            }
        };
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(20, 24, 22, 24));
        return p;
    }

    /** Draws the little paper plane used in the header and on the login screen. */
    static void plane(Graphics2D g2, int x, int y, double scale) {
        aa(g2);
        java.awt.geom.AffineTransform old = g2.getTransform();
        g2.translate(x, y);
        g2.scale(scale, scale);
        g2.setColor(AMBER);
        g2.fillPolygon(new int[] {0, 96, 52, 44}, new int[] {38, 0, 78, 46}, 4);
        g2.setColor(new Color(0xC98A12));
        g2.fillPolygon(new int[] {44, 52, 28}, new int[] {46, 78, 70}, 3);
        g2.setTransform(old);
    }

    /** Dark title strip at the top of the passenger and administrator windows. */
    static JPanel headerBar(String title, String subtitle, JComponent right) {
        JPanel bar = new JPanel(new BorderLayout()) {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                aa(g2);
                g2.setPaint(new GradientPaint(0, 0, NAVY, getWidth(), 0, MID));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 10));
                g2.fillOval(getWidth() - 260, -140, 320, 320);
                g2.fillOval(getWidth() - 120, -40, 200, 200);
                g2.setColor(AMBER);
                g2.fillRect(0, getHeight() - 3, getWidth(), 3);
                g2.dispose();
            }
        };
        bar.setOpaque(false);
        bar.setBorder(BorderFactory.createEmptyBorder(16, 24, 18, 24));
        JPanel icon = new JPanel() {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                plane(g2, 4, 6, 0.42);
                g2.dispose();
            }
        };
        icon.setOpaque(false);
        icon.setPreferredSize(new Dimension(52, 44));
        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.add(label(title, Font.BOLD, 21, Color.WHITE));
        text.add(Box.createVerticalStrut(3));
        text.add(label(subtitle, Font.PLAIN, 13, new Color(0xA9B7D0)));
        JPanel left = new JPanel(new BorderLayout());
        left.setOpaque(false);
        left.add(icon, BorderLayout.WEST);
        left.add(text, BorderLayout.CENTER);
        bar.add(left, BorderLayout.WEST);
        if (right != null) {
            JPanel r = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 6));
            r.setOpaque(false);
            r.add(right);
            bar.add(r, BorderLayout.EAST);
        }
        return bar;
    }

    /** Flat tab strip with an amber underline under the selected tab. */
    static JTabbedPane tabs() {
        JTabbedPane t = new JTabbedPane();
        t.setFont(font(Font.BOLD, 14));
        t.setOpaque(false);
        t.setForeground(MUTED);
        t.setUI(new BasicTabbedPaneUI() {
            @Override
            protected void installDefaults() {
                super.installDefaults();
                tabAreaInsets = new Insets(0, 0, 6, 0);
                contentBorderInsets = new Insets(0, 0, 0, 0);
                tabInsets = new Insets(8, 18, 8, 18);
                selectedTabPadInsets = new Insets(0, 0, 0, 0);
            }

            @Override
            protected void paintTabBackground(Graphics g, int p, int i, int x, int y, int w, int h, boolean sel) {
            }

            @Override
            protected void paintTabBorder(Graphics g, int p, int i, int x, int y, int w, int h, boolean sel) {
                if (sel) {
                    g.setColor(BLUE);
                    g.fillRect(x + 10, y + h - 3, w - 20, 3);
                }
            }

            @Override
            protected void paintContentBorder(Graphics g, int p, int sel) {
            }

            @Override
            protected void paintFocusIndicator(Graphics g, int p, Rectangle[] r, int i, Rectangle ir,
                                               Rectangle tr, boolean sel) {
            }

            @Override
            protected void paintText(Graphics g, int p, Font f, java.awt.FontMetrics m, int i, String title,
                                     Rectangle tr, boolean sel) {
                Graphics2D g2 = (Graphics2D) g.create();
                aa(g2);
                g2.setFont(f);
                g2.setColor(sel ? NAVY : MUTED);
                g2.drawString(title, tr.x, tr.y + m.getAscent());
                g2.dispose();
            }
        });
        return t;
    }

    // --------------------------------------------------------------- tables

    static DefaultTableModel model(String... columns) {
        return new DefaultTableModel(columns, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    static JTable table(DefaultTableModel model) {
        JTable t = new JTable(model);
        t.setFont(font(Font.PLAIN, 13));
        t.setRowHeight(36);
        t.setGridColor(new Color(0xEDF1F8));
        t.setShowVerticalLines(false);
        t.setShowHorizontalLines(true);
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        t.setSelectionBackground(new Color(0xCFE0FA));
        t.setSelectionForeground(INK);
        t.setForeground(INK);
        t.setFillsViewportHeight(true);
        t.setIntercellSpacing(new Dimension(0, 1));
        t.getTableHeader().setReorderingAllowed(false);

        JTableHeader header = t.getTableHeader();
        header.setPreferredSize(new Dimension(100, 38));
        header.setBorder(BorderFactory.createEmptyBorder());
        DefaultTableCellRenderer headRenderer = new DefaultTableCellRenderer() {
            private static final long serialVersionUID = 1L;

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean sel,
                                                           boolean focus, int row, int col) {
                super.getTableCellRendererComponent(table, value, sel, focus, row, col);
                setBackground(NAVY);
                setForeground(Color.WHITE);
                setFont(font(Font.BOLD, 13));
                setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
                String cn = String.valueOf(value);
                setHorizontalAlignment("Fare".equals(cn) || "Seats left".equals(cn) || "Available".equals(cn)
                        || "Total seats".equals(cn) ? SwingConstants.RIGHT : SwingConstants.LEFT);
                return this;
            }
        };
        header.setDefaultRenderer(headRenderer);

        DefaultTableCellRenderer body = new DefaultTableCellRenderer() {
            private static final long serialVersionUID = 1L;

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean sel,
                                                           boolean focus, int row, int col) {
                super.getTableCellRendererComponent(table, value, sel, focus, row, col);
                setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
                if (!sel) {
                    setBackground(row % 2 == 0 ? Color.WHITE : new Color(0xF8FAFD));
                }
                setForeground(INK);
                setFont(font(Font.PLAIN, 13));
                String colName = table.getColumnName(col);
                setHorizontalAlignment(value != null && ("Fare".equals(colName) || "Seats left".equals(colName)
                        || "Available".equals(colName) || "Total seats".equals(colName))
                        ? SwingConstants.RIGHT : SwingConstants.LEFT);
                if ("Status".equals(colName) && value != null) {
                    boolean ok = "Confirmed".equals(value.toString());
                    JLabel pill = pill(value.toString(), ok ? GREEN : RED,
                            ok ? new Color(0xDDF3E7) : new Color(0xFBE3E1));
                    JPanel wrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 6));
                    wrap.setBackground(sel ? table.getSelectionBackground()
                            : (row % 2 == 0 ? Color.WHITE : new Color(0xF8FAFD)));
                    wrap.add(pill);
                    return wrap;
                }
                if (("Seats left".equals(colName) || "Available".equals(colName)) && value instanceof Number) {
                    int n = ((Number) value).intValue();
                    setFont(font(Font.BOLD, 13));
                    setForeground(n <= 10 ? RED : (n <= 30 ? new Color(0xB36B00) : GREEN));
                } else if ("Fare".equals(colName) || "Flight".equals(colName) || "PNR".equals(colName)) {
                    setFont(font(Font.BOLD, 13));
                }
                return this;
            }
        };
        t.setDefaultRenderer(Object.class, body);
        return t;
    }

    static void widths(JTable table, int... widths) {
        for (int i = 0; i < widths.length && i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
    }

    static JScrollPane scroll(JTable table) {
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(new Color(0xE3E9F4)));
        sp.getViewport().setBackground(Color.WHITE);
        JTableHeader h = table.getTableHeader();
        h.setOpaque(true);
        sp.setCorner(JScrollPane.UPPER_RIGHT_CORNER, cornerFill());
        sp.getVerticalScrollBar().setUI(new SlimScrollBarUI());
        sp.getHorizontalScrollBar().setUI(new SlimScrollBarUI());
        sp.getVerticalScrollBar().setPreferredSize(new Dimension(10, 10));
        sp.getHorizontalScrollBar().setPreferredSize(new Dimension(10, 10));
        return sp;
    }

    private static JPanel cornerFill() {
        JPanel p = new JPanel();
        p.setBackground(NAVY);
        return p;
    }

    static final class SlimScrollBarUI extends BasicScrollBarUI {
        @Override
        protected void configureScrollBarColors() {
            thumbColor = new Color(0xC3CDE0);
            trackColor = Color.WHITE;
        }

        @Override
        protected javax.swing.JButton createDecreaseButton(int o) {
            return zero();
        }

        @Override
        protected javax.swing.JButton createIncreaseButton(int o) {
            return zero();
        }

        private static javax.swing.JButton zero() {
            javax.swing.JButton b = new javax.swing.JButton();
            b.setPreferredSize(new Dimension(0, 0));
            return b;
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            g2.setColor(thumbColor);
            g2.fillRoundRect(r.x + 1, r.y + 1, r.width - 2, r.height - 2, 8, 8);
            g2.dispose();
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
            g.setColor(trackColor);
            g.fillRect(r.x, r.y, r.width, r.height);
        }
    }

    // -------------------------------------------------------------- dialogs

    static void error(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Airline Reservation System", JOptionPane.ERROR_MESSAGE);
    }

    static void info(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Airline Reservation System",
                JOptionPane.INFORMATION_MESSAGE);
    }

    static boolean confirm(Component parent, String message) {
        return JOptionPane.showConfirmDialog(parent, message, "Airline Reservation System",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION;
    }

    // --------------------------------------------------------------- button

    /** A flat, rounded button painted by hand so it looks the same on every operating system. */
    static final class AppButton extends JButton {
        private static final long serialVersionUID = 1L;
        private Color base;
        private boolean hover;

        AppButton(String text, Color base) {
            super(text);
            this.base = base;
            setFont(font(Font.BOLD, 13));
            setForeground(base.equals(AMBER) ? NAVY : Color.WHITE);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setHorizontalAlignment(SwingConstants.CENTER);
            setMargin(new java.awt.Insets(8, 18, 8, 18));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hover = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover = false;
                    repaint();
                }
            });
        }

        void setBackgroundColor(Color c) {
            this.base = c;
            repaint();
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension d = super.getPreferredSize();
            if (isPreferredSizeSet()) {
                return super.getPreferredSize();
            }
            return new Dimension(d.width + 14, Math.max(d.height, 38));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            aa(g2);
            Color fill = !isEnabled() ? new Color(0xB8C0D0) : (hover ? base.brighter() : base);
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
