package airline.ui;

import airline.AirlineException;
import airline.data.PaymentService;
import airline.model.Payment;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Window;

/** Second step of a booking: the passenger chooses a payment method and pays (simulated gateway). */
class PaymentDialog extends JDialog {
    private static final long serialVersionUID = 1L;
    private static final String[] METHODS = {Payment.UPI, Payment.CARD, Payment.NET_BANKING, Payment.WALLET};
    private static final Color PALE_BTN = new Color(0xD5DDEC);

    private final double amount;
    private final Ui.AppButton[] tabs = new Ui.AppButton[METHODS.length];
    private final CardLayout cards = new CardLayout();
    private final JPanel cardPanel = new JPanel(cards);
    private String method = Payment.UPI;
    private Payment result;

    // package-private so the automated GUI test can drive them
    final JTextField upiId = Ui.field(20);
    final JTextField cardName = Ui.field(20);
    final JTextField cardNumber = Ui.field(20);
    final JTextField cardExpiry = Ui.field(8);
    final JPasswordField cardCvv = Ui.password(6);
    final JComboBox<String> bank = Ui.combo(new JComboBox<>(PaymentService.BANKS));
    final JComboBox<String> wallet = Ui.combo(new JComboBox<>(PaymentService.WALLETS));
    final JTextField walletMobile = Ui.field(14);
    final JLabel message = Ui.label(" ", Font.PLAIN, 13, Ui.RED);
    final Ui.AppButton payButton;

    PaymentDialog(JDialog parent, String title, String subtitle, double amount) {
        super(parent, "Payment", true);
        this.amount = amount;
        payButton = Ui.button("Pay " + Ui.money(amount), Ui.GREEN);

        JPanel root = new JPanel(new BorderLayout(0, 14));
        root.setBackground(Ui.BG);
        root.setBorder(BorderFactory.createEmptyBorder(18, 22, 16, 22));
        root.add(header(title, subtitle), BorderLayout.NORTH);
        root.add(body(), BorderLayout.CENTER);
        root.add(footer(), BorderLayout.SOUTH);
        setContentPane(root);
        select(Payment.UPI);
        pack();
        setMinimumSize(new Dimension(460, getHeight()));
        setLocationRelativeTo(parent);
    }

    Payment getResult() {
        return result;
    }

    private JPanel header(String title, String subtitle) {
        JPanel p = new JPanel();
        p.setBackground(Ui.NAVY);
        p.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.add(Ui.label("Amount to pay", Font.PLAIN, 12, new Color(0xA9B7D0)));
        p.add(Ui.label(Ui.money(amount), Font.BOLD, 26, Color.WHITE));
        p.add(Box.createVerticalStrut(2));
        p.add(Ui.label(title + "   |   " + subtitle, Font.PLAIN, 13, Ui.AMBER));
        return p;
    }

    private JPanel body() {
        JPanel strip = new JPanel(new GridLayout(1, METHODS.length, 8, 0));
        strip.setOpaque(false);
        for (int i = 0; i < METHODS.length; i++) {
            final String m = METHODS[i];
            tabs[i] = Ui.button(m, PALE_BTN);
            tabs[i].addActionListener(e -> select(m));
            strip.add(tabs[i]);
        }

        cardPanel.setOpaque(false);
        cardPanel.add(form(new String[] {"UPI ID"}, new Component[] {upiId}), Payment.UPI);
        cardPanel.add(form(new String[] {"NAME ON CARD", "CARD NUMBER", "EXPIRY (MM/YY)", "CVV"},
                new Component[] {cardName, cardNumber, cardExpiry, cardCvv}), Payment.CARD);
        cardPanel.add(form(new String[] {"SELECT YOUR BANK"}, new Component[] {bank}), Payment.NET_BANKING);
        cardPanel.add(form(new String[] {"WALLET", "WALLET MOBILE NUMBER"},
                new Component[] {wallet, walletMobile}), Payment.WALLET);

        JPanel card = Ui.card();
        card.setLayout(new BorderLayout(0, 10));
        card.add(cardPanel, BorderLayout.CENTER);
        card.add(message, BorderLayout.SOUTH);

        JPanel p = new JPanel(new BorderLayout(0, 12));
        p.setOpaque(false);
        p.add(strip, BorderLayout.NORTH);
        p.add(card, BorderLayout.CENTER);
        return p;
    }

    private static JPanel form(String[] labels, Component[] fields) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        for (int i = 0; i < labels.length; i++) {
            JLabel l = Ui.fieldLabel(labels[i]);
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            p.add(l);
            p.add(Box.createVerticalStrut(4));
            javax.swing.JComponent f = (javax.swing.JComponent) fields[i];
            f.setAlignmentX(Component.LEFT_ALIGNMENT);
            f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
            p.add(f);
            p.add(Box.createVerticalStrut(10));
        }
        return p;
    }

    private JPanel footer() {
        JPanel note = new JPanel();
        note.setOpaque(false);
        note.setLayout(new BoxLayout(note, BoxLayout.Y_AXIS));
        note.add(Ui.label("Demo gateway: no real money is charged and card details are not saved.",
                Font.PLAIN, 12, Ui.MUTED));
        note.add(Ui.label("Test card 4111 1111 1111 1111 (any future expiry, any CVV).", Font.PLAIN, 12, Ui.MUTED));

        Ui.AppButton cancel = Ui.button("Back", Ui.MUTED);
        cancel.addActionListener(e -> dispose());
        payButton.addActionListener(e -> pay());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttons.setOpaque(false);
        buttons.add(cancel);
        buttons.add(payButton);
        getRootPane().setDefaultButton(payButton);

        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setOpaque(false);
        p.add(buttons, BorderLayout.NORTH);
        p.add(note, BorderLayout.SOUTH);
        return p;
    }

    void select(String m) {
        method = m;
        cards.show(cardPanel, m);
        message.setText(" ");
        for (int i = 0; i < METHODS.length; i++) {
            boolean on = METHODS[i].equals(m);
            tabs[i].setBackgroundColor(on ? Ui.BLUE : PALE_BTN);
            tabs[i].setForeground(on ? Color.WHITE : Ui.MUTED);
        }
    }

    String selectedMethod() {
        return method;
    }

    /** Validates the chosen method and, when it succeeds, closes the dialog with a result. */
    void pay() {
        try {
            switch (method) {
                case Payment.CARD:
                    result = PaymentService.payCard(cardName.getText(), cardNumber.getText(),
                            cardExpiry.getText(), new String(cardCvv.getPassword()));
                    break;
                case Payment.NET_BANKING:
                    result = PaymentService.payNetBanking((String) bank.getSelectedItem());
                    break;
                case Payment.WALLET:
                    result = PaymentService.payWallet((String) wallet.getSelectedItem(), walletMobile.getText());
                    break;
                default:
                    result = PaymentService.payUpi(upiId.getText());
                    break;
            }
            cardCvv.setText("");
            cardNumber.setText("");
            dispose();
        } catch (AirlineException ex) {
            result = null;
            message.setText(ex.getMessage());
            pack();
        }
    }
}
