package airline.ui;

import airline.AirlineException;
import airline.data.Config;
import airline.data.Repository;
import airline.data.SampleData;
import airline.model.User;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;

/** First screen: passenger / administrator login and passenger registration. */
public class LoginFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private static final String CARD_LOGIN = "login";
    private static final String CARD_REGISTER = "register";

    private final Repository repo;
    private final Config config;

    // components are package-private so that the automated GUI test can drive them
    final JRadioButton passengerRadio = new JRadioButton("Passenger", true);
    final JRadioButton adminRadio = new JRadioButton("Administrator");
    final JLabel idLabel = Ui.fieldLabel("EMAIL");
    final JTextField loginId = Ui.field(22);
    final JPasswordField loginPassword = Ui.password(22);
    final JLabel loginMessage = Ui.label(" ", Font.PLAIN, 13, Ui.RED);
    final Ui.AppButton loginButton = Ui.button("Login", Ui.BLUE);

    final JTextField regName = Ui.field(22);
    final JTextField regEmail = Ui.field(22);
    final JTextField regPhone = Ui.field(22);
    final JPasswordField regPassword = Ui.password(22);
    final JPasswordField regConfirm = Ui.password(22);
    final JLabel registerMessage = Ui.label(" ", Font.PLAIN, 13, Ui.RED);
    final Ui.AppButton registerButton = Ui.button("Create account", Ui.BLUE);

    private final CardLayout cards = new CardLayout();
    private final JPanel cardPanel = new JPanel(cards);
    private final Ui.AppButton loginTab = Ui.button("Login", Ui.NAVY);
    private final Ui.AppButton registerTab = Ui.button("Create account", Ui.NAVY);

    public LoginFrame(Repository repo, Config config) {
        super("Airline Reservation System");
        this.repo = repo;
        this.config = config;
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout());
        root.add(new BrandPanel(), BorderLayout.WEST);
        root.add(buildFormSide(), BorderLayout.CENTER);
        setContentPane(root);

        setSize(980, 620);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);
        showCard(CARD_LOGIN);
    }

    // --------------------------------------------------------------- layout

    private JPanel buildFormSide() {
        JPanel side = new JPanel(new BorderLayout());
        side.setBackground(Ui.BG);
        side.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));

        JPanel tabs = new JPanel();
        tabs.setOpaque(false);
        tabs.setLayout(new BoxLayout(tabs, BoxLayout.X_AXIS));
        tabs.add(loginTab);
        tabs.add(Box.createHorizontalStrut(8));
        tabs.add(registerTab);
        tabs.add(Box.createHorizontalGlue());
        loginTab.addActionListener(e -> showCard(CARD_LOGIN));
        registerTab.addActionListener(e -> showCard(CARD_REGISTER));

        cardPanel.setOpaque(false);
        cardPanel.add(buildLoginCard(), CARD_LOGIN);
        cardPanel.add(buildRegisterCard(), CARD_REGISTER);

        JPanel footer = new JPanel();
        footer.setOpaque(false);
        footer.setLayout(new BoxLayout(footer, BoxLayout.Y_AXIS));
        footer.setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 0));
        footer.add(Ui.label("Demo passenger:  " + SampleData.DEMO_EMAIL + "  /  " + SampleData.DEMO_PASSWORD,
                Font.PLAIN, 12, Ui.MUTED));
        footer.add(Ui.label("Administrator:  " + config.adminUser() + "  /  " + config.adminPassword(),
                Font.PLAIN, 12, Ui.MUTED));
        footer.add(Box.createVerticalStrut(4));
        footer.add(Ui.label("Data source:  " + repo.describe(), Font.BOLD, 12, Ui.BLUE));

        JPanel column = new JPanel(new BorderLayout(0, 14));
        column.setOpaque(false);
        column.setPreferredSize(new Dimension(440, 470));
        column.add(tabs, BorderLayout.NORTH);
        column.add(cardPanel, BorderLayout.CENTER);
        column.add(footer, BorderLayout.SOUTH);
        JPanel centre = new JPanel(new GridBagLayout());
        centre.setOpaque(false);
        centre.add(column);
        side.add(centre, BorderLayout.CENTER);
        return side;
    }

    private JPanel buildLoginCard() {
        JPanel card = Ui.card();
        card.setLayout(new GridBagLayout());

        ButtonGroup group = new ButtonGroup();
        group.add(passengerRadio);
        group.add(adminRadio);
        for (JRadioButton rb : new JRadioButton[] {passengerRadio, adminRadio}) {
            rb.setOpaque(false);
            rb.setFont(Ui.font(Font.BOLD, 14));
            rb.setForeground(Ui.INK);
            rb.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
            rb.setFocusPainted(false);
        }
        passengerRadio.addActionListener(e -> updateRole());
        adminRadio.addActionListener(e -> updateRole());

        JPanel roles = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 0, 0));
        roles.setOpaque(false);
        roles.add(passengerRadio);
        roles.add(Box.createHorizontalStrut(14));
        roles.add(adminRadio);

        int row = 0;
        addRow(card, row++, Ui.label("Welcome back", Font.BOLD, 26, Ui.NAVY), null);
        addRow(card, row++, Ui.label("Log in to search flights and manage bookings.", Font.PLAIN, 13, Ui.MUTED), null);
        addRow(card, row++, Ui.fieldLabel("LOGIN AS"), roles);
        addRow(card, row++, idLabel, loginId);
        addRow(card, row++, Ui.fieldLabel("PASSWORD"), loginPassword);
        addRow(card, row++, loginMessage, null);
        loginButton.setPreferredSize(new Dimension(100, 42));
        addRow(card, row++, null, loginButton);
        loginButton.addActionListener(e -> doLogin());
        return card;
    }

    private JPanel buildRegisterCard() {
        JPanel card = Ui.card();
        card.setLayout(new GridBagLayout());
        int row = 0;
        addRow(card, row++, Ui.label("Create your account", Font.BOLD, 26, Ui.NAVY), null);
        addRow(card, row++, Ui.label("Takes a minute. Book flights and keep every PNR in one place.", Font.PLAIN, 13, Ui.MUTED), null);
        addRow(card, row++, Ui.fieldLabel("FULL NAME"), regName);
        addRow(card, row++, Ui.fieldLabel("EMAIL"), regEmail);
        addRow(card, row++, Ui.fieldLabel("PHONE (10 DIGITS)"), regPhone);
        addRow(card, row++, Ui.fieldLabel("PASSWORD"), regPassword);
        addRow(card, row++, Ui.fieldLabel("CONFIRM PASSWORD"), regConfirm);
        addRow(card, row++, registerMessage, null);
        registerButton.setPreferredSize(new Dimension(100, 42));
        addRow(card, row++, null, registerButton);
        registerButton.addActionListener(e -> doRegister());
        return card;
    }

    private static void addRow(JPanel p, int row, JLabel label, java.awt.Component field) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = row;
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        c.insets = new Insets(label != null && field != null ? 8 : 4, 0, 2, 0);
        JPanel cell = new JPanel();
        cell.setOpaque(false);
        cell.setLayout(new BoxLayout(cell, BoxLayout.Y_AXIS));
        if (label != null) {
            label.setAlignmentX(LEFT_ALIGNMENT);
            cell.add(label);
        }
        if (field != null) {
            if (label != null) {
                cell.add(Box.createVerticalStrut(4));
            }
            ((javax.swing.JComponent) field).setAlignmentX(LEFT_ALIGNMENT);
            if (field instanceof JTextField) {
                field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
            }
            if (field instanceof Ui.AppButton) {
                field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            }
            cell.add(field);
        }
        p.add(cell, c);
    }

    void showCard(String name) {
        cards.show(cardPanel, name);
        boolean login = CARD_LOGIN.equals(name);
        loginTab.setBackgroundColor(login ? Ui.NAVY : new Color(0xD5DDEC));
        registerTab.setBackgroundColor(login ? new Color(0xD5DDEC) : Ui.NAVY);
        loginTab.setForeground(login ? Color.WHITE : Ui.MUTED);
        registerTab.setForeground(login ? Ui.MUTED : Color.WHITE);
        getRootPane().setDefaultButton(login ? loginButton : registerButton);
        loginMessage.setText(" ");
        registerMessage.setText(" ");
    }

    private void updateRole() {
        idLabel.setText(adminRadio.isSelected() ? "ADMIN USERNAME" : "EMAIL");
        loginMessage.setText(" ");
    }

    // -------------------------------------------------------------- actions

    void doLogin() {
        String id = loginId.getText().trim();
        String pw = new String(loginPassword.getPassword());
        if (id.isEmpty() || pw.isEmpty()) {
            loginError("Please enter your " + (adminRadio.isSelected() ? "username" : "email")
                    + " and password.");
            return;
        }
        if (adminRadio.isSelected()) {
            if (id.equals(config.adminUser()) && pw.equals(config.adminPassword())) {
                setVisible(false);
                dispose();
                new AdminFrame(repo, () -> new LoginFrame(repo, config).setVisible(true)).setVisible(true);
            } else {
                loginError("Wrong administrator username or password.");
            }
            return;
        }
        try {
            User user = repo.login(id, pw);
            if (user == null) {
                loginError("Wrong email or password.");
                return;
            }
            setVisible(false);
            dispose();
            new PassengerFrame(repo, user, () -> new LoginFrame(repo, config).setVisible(true)).setVisible(true);
        } catch (AirlineException ex) {
            Ui.error(this, ex.getMessage());
        }
    }

    private void loginError(String message) {
        loginMessage.setForeground(Ui.RED);
        loginMessage.setText(message);
    }

    void doRegister() {
        String pw = new String(regPassword.getPassword());
        if (!pw.equals(new String(regConfirm.getPassword()))) {
            registerMessage.setForeground(Ui.RED);
            registerMessage.setText("The two passwords do not match.");
            return;
        }
        try {
            User u = repo.register(regName.getText(), regEmail.getText(), pw, regPhone.getText());
            passengerRadio.setSelected(true);
            updateRole();
            showCard(CARD_LOGIN);
            loginId.setText(u.getEmail());
            loginPassword.setText("");
            loginMessage.setForeground(Ui.GREEN);
            loginMessage.setText("Account created. Please log in.");
            regName.setText("");
            regEmail.setText("");
            regPhone.setText("");
            regPassword.setText("");
            regConfirm.setText("");
        } catch (AirlineException ex) {
            registerMessage.setForeground(Ui.RED);
            registerMessage.setText(ex.getMessage());
        }
    }

    // ---------------------------------------------------------- brand panel

    /** Gradient panel on the left with the project title, a drawn paper plane and a few selling points. */
    private static final class BrandPanel extends JPanel {
        private static final long serialVersionUID = 1L;

        BrandPanel() {
            setPreferredSize(new Dimension(380, 600));
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            setBorder(BorderFactory.createEmptyBorder(160, 40, 30, 30));
            add(Ui.label("BCA MINOR PROJECT", Font.BOLD, 12, Ui.AMBER));
            add(Box.createVerticalStrut(10));
            add(Ui.label("Airline", Font.BOLD, 40, Color.WHITE));
            add(Ui.label("Reservation", Font.BOLD, 40, Color.WHITE));
            add(Ui.label("System", Font.BOLD, 40, Color.WHITE));
            add(Box.createVerticalStrut(18));
            Color soft = new Color(0xC9D5EA);
            add(Ui.label("\u2713  Search flights by route and date", Font.PLAIN, 14, soft));
            add(Box.createVerticalStrut(6));
            add(Ui.label("\u2713  Book a seat and get your PNR", Font.PLAIN, 14, soft));
            add(Box.createVerticalStrut(6));
            add(Ui.label("\u2713  Cancel any time, seat is released", Font.PLAIN, 14, soft));
            add(Box.createVerticalGlue());
            add(Ui.label("Arman Bishoi  |  Roll No. 240845106029", Font.PLAIN, 12, new Color(0xA9B7D0)));
            add(Ui.label("Guide: Mr. Kamal Nain  |  INMANTEC, Ghaziabad", Font.PLAIN, 12, new Color(0xA9B7D0)));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            Ui.aa(g2);
            int w = getWidth();
            int h = getHeight();
            g2.setPaint(new GradientPaint(0, 0, Ui.NAVY, w, h, Ui.BLUE.darker()));
            g2.fillRect(0, 0, w, h);
            // soft decorative circles
            g2.setColor(new Color(255, 255, 255, 14));
            g2.fillOval(w - 170, -90, 300, 300);
            g2.setColor(new Color(255, 255, 255, 10));
            g2.fillOval(-120, h - 230, 330, 330);
            g2.setColor(new Color(242, 177, 52, 40));
            g2.setStroke(new java.awt.BasicStroke(2f, java.awt.BasicStroke.CAP_ROUND,
                    java.awt.BasicStroke.JOIN_ROUND, 1f, new float[] {2f, 9f}, 0f));
            g2.drawArc(-40, 40, w + 40, 220, 0, 160);
            Ui.plane(g2, 40, 70, 1.0);
            g2.dispose();
        }
    }
}
