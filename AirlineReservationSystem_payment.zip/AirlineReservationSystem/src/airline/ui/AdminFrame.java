package airline.ui;

import airline.AirlineException;
import airline.data.Repository;
import airline.data.Rules;
import airline.model.Booking;
import airline.model.Flight;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;

/** Administrator window: manage flights and monitor every booking. */
public class AdminFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private final Repository repo;

    final DefaultTableModel flightModel = Ui.model("ID", "Flight", "From", "To", "Date", "Departs", "Arrives",
            "Total seats", "Available", "Fare");
    final JTable flightTable = Ui.table(flightModel);
    private List<Flight> flights = new ArrayList<>();

    final DefaultTableModel bookingModel = Ui.model("PNR", "Passenger", "Age", "Gender", "Booked by", "Flight",
            "Route", "Travel date", "Seat", "Fare", "Status", "Payment", "Transaction ID");
    final JTable bookingTable = Ui.table(bookingModel);
    final JLabel summary = Ui.label(" ", Font.BOLD, 13, Ui.NAVY);
    final JTabbedPane tabs = Ui.tabs();

    public AdminFrame(Repository repo, Runnable onLogout) {
        super("Airline Reservation System - Administrator");
        this.repo = repo;
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        Ui.AppButton logout = Ui.button("Logout", Ui.MID);
        logout.addActionListener(e -> {
            dispose();
            onLogout.run();
        });

        tabs.addTab("Flights", buildFlightsTab());
        tabs.addTab("All bookings", buildBookingsTab());
        tabs.addChangeListener(e -> {
            if (tabs.getSelectedIndex() == 1) {
                reloadBookings();
            }
        });

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Ui.BG);
        root.add(Ui.headerBar("Administrator", repo.describe(), logout), BorderLayout.NORTH);
        JPanel body = new JPanel(new BorderLayout());
        body.setOpaque(false);
        body.setBorder(BorderFactory.createEmptyBorder(14, 20, 14, 20));
        body.add(tabs, BorderLayout.CENTER);
        root.add(body, BorderLayout.CENTER);
        setContentPane(root);

        setSize(1180, 690);
        setMinimumSize(new Dimension(1000, 600));
        setLocationRelativeTo(null);
        reloadFlights();
    }

    // ----------------------------------------------------------- flights tab

    private JPanel buildFlightsTab() {
        JPanel tab = new JPanel(new BorderLayout(0, 10));
        tab.setBackground(Ui.BG);
        tab.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));

        Ui.AppButton add = Ui.button("Add flight", Ui.BLUE);
        Ui.AppButton edit = Ui.button("Edit selected", Ui.AMBER);
        Ui.AppButton delete = Ui.button("Delete selected", Ui.RED);
        Ui.AppButton refresh = Ui.button("Refresh", Ui.MID);
        add.addActionListener(e -> addFlight());
        edit.addActionListener(e -> editFlight());
        delete.addActionListener(e -> deleteFlight());
        refresh.addActionListener(e -> reloadFlights());

        JPanel bar = Ui.card();
        bar.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 0));
        bar.setBorder(BorderFactory.createEmptyBorder(10, 16, 12, 16));
        bar.add(add);
        bar.add(edit);
        bar.add(delete);
        bar.add(refresh);

        Ui.widths(flightTable, 40, 70, 110, 110, 110, 80, 80, 90, 80, 90);
        tab.add(bar, BorderLayout.NORTH);
        tab.add(Ui.scroll(flightTable), BorderLayout.CENTER);
        return tab;
    }

    void reloadFlights() {
        try {
            flights = repo.allFlights();
            flightModel.setRowCount(0);
            for (Flight f : flights) {
                flightModel.addRow(new Object[] {f.getId(), f.getFlightNumber(), f.getSource(), f.getDestination(),
                        f.getTravelDate().format(Rules.DATE_SHOW), f.getDepartureTime().format(Rules.TIME_FMT),
                        f.getArrivalTime().format(Rules.TIME_FMT), f.getTotalSeats(), f.getAvailableSeats(),
                        Ui.money(f.getPrice())});
            }
        } catch (AirlineException ex) {
            Ui.error(this, ex.getMessage());
        }
    }

    private Flight selectedFlight() {
        int row = flightTable.getSelectedRow();
        if (row < 0 || row >= flights.size()) {
            Ui.info(this, "Please select a flight in the table first.");
            return null;
        }
        return flights.get(row);
    }

    void addFlight() {
        FlightDialog d = new FlightDialog(this, repo, null);
        d.setVisible(true);
        if (d.isSaved()) {
            reloadFlights();
        }
    }

    void editFlight() {
        Flight f = selectedFlight();
        if (f == null) {
            return;
        }
        FlightDialog d = new FlightDialog(this, repo, f);
        d.setVisible(true);
        if (d.isSaved()) {
            reloadFlights();
        }
    }

    void deleteFlight() {
        Flight f = selectedFlight();
        if (f == null) {
            return;
        }
        if (!Ui.confirm(this, "Delete flight " + f.getFlightNumber() + " (" + f.getRoute() + ")?")) {
            return;
        }
        try {
            repo.deleteFlight(f.getId());
            reloadFlights();
        } catch (AirlineException ex) {
            Ui.error(this, ex.getMessage());
        }
    }

    // ---------------------------------------------------------- bookings tab

    private JPanel buildBookingsTab() {
        JPanel tab = new JPanel(new BorderLayout(0, 10));
        tab.setBackground(Ui.BG);
        tab.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));

        Ui.AppButton refresh = Ui.button("Refresh", Ui.MID);
        refresh.addActionListener(e -> reloadBookings());
        JPanel bar = Ui.card();
        bar.setLayout(new BorderLayout());
        bar.setBorder(BorderFactory.createEmptyBorder(10, 16, 12, 16));
        bar.add(summary, BorderLayout.CENTER);
        bar.add(refresh, BorderLayout.EAST);

        Ui.widths(bookingTable, 85, 120, 40, 60, 160, 55, 150, 95, 40, 80, 85, 130, 120);
        tab.add(bar, BorderLayout.NORTH);
        tab.add(Ui.scroll(bookingTable), BorderLayout.CENTER);
        return tab;
    }

    void reloadBookings() {
        try {
            List<Booking> all = repo.allBookings();
            bookingModel.setRowCount(0);
            int confirmed = 0;
            double revenue = 0;
            for (Booking b : all) {
                if (Rules.CONFIRMED.equals(b.getStatus())) {
                    confirmed++;
                    revenue += b.getPrice();
                }
                bookingModel.addRow(new Object[] {b.getPnr(), b.getPassengerName(), b.getPassengerAge(),
                        b.getPassengerGender(), b.getUserEmail(), b.getFlightNumber(), b.getRoute(),
                        b.getTravelDate().format(Rules.DATE_SHOW), b.getSeatNumber(), Ui.money(b.getPrice()),
                        b.getStatus(), b.getPaymentSummary(),
                        b.getTransactionId() == null ? "-" : b.getTransactionId()});
            }
            summary.setForeground(Color.decode("#0E1B33"));
            summary.setText(all.size() + " booking(s)   |   " + confirmed + " confirmed   |   "
                    + (all.size() - confirmed) + " cancelled   |   confirmed fares total " + Ui.money(revenue));
        } catch (AirlineException ex) {
            Ui.error(this, ex.getMessage());
        }
    }
}
