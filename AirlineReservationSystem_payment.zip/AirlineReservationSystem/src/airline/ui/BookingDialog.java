package airline.ui;

import airline.AirlineException;
import airline.data.Repository;
import airline.data.Rules;
import airline.model.Booking;
import airline.model.Flight;
import airline.model.Payment;
import airline.model.User;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

/** Asks for the passenger details of one flight and makes the booking. */
class BookingDialog extends JDialog {
    private static final long serialVersionUID = 1L;

    private final Repository repo;
    private final User user;
    private final Flight flight;

    final JTextField nameField;
    final JTextField ageField = Ui.field(8);
    final JComboBox<String> genderBox = new JComboBox<>(new String[] {"Male", "Female", "Other"});
    private final JLabel message = Ui.label(" ", Font.PLAIN, 13, Ui.RED);
    private Booking result;

    BookingDialog(JFrame parent, Repository repo, User user, Flight flight) {
        super(parent, "Book flight " + flight.getFlightNumber(), true);
        this.repo = repo;
        this.user = user;
        this.flight = flight;
        nameField = Ui.field(22);
        nameField.setText(user.getName());
        Ui.combo(genderBox);
        genderBox.setPreferredSize(new java.awt.Dimension(160, 36));

        JPanel root = new JPanel(new BorderLayout(0, 14));
        root.setBackground(Ui.BG);
        root.setBorder(BorderFactory.createEmptyBorder(18, 22, 16, 22));
        root.add(summary(), BorderLayout.NORTH);
        root.add(form(), BorderLayout.CENTER);
        root.add(buttons(), BorderLayout.SOUTH);
        setContentPane(root);
        pack();
        setLocationRelativeTo(parent);
    }

    Booking getResult() {
        return result;
    }

    private JPanel summary() {
        JPanel p = new JPanel();
        p.setBackground(Ui.NAVY);
        p.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.add(Ui.label(flight.getFlightNumber() + "   " + flight.getRoute(), Font.BOLD, 18, Color.WHITE));
        p.add(Box.createVerticalStrut(4));
        p.add(Ui.label(flight.getTravelDate().format(Rules.DATE_SHOW) + "   |   departs "
                + flight.getDepartureTime().format(Rules.TIME_FMT) + "   arrives "
                + flight.getArrivalTime().format(Rules.TIME_FMT), Font.PLAIN, 13, new Color(0xC9D5EA)));
        p.add(Box.createVerticalStrut(2));
        p.add(Ui.label("Fare " + Ui.money(flight.getPrice()) + "   |   " + flight.getAvailableSeats()
                + " seats left", Font.BOLD, 13, Ui.AMBER));
        return p;
    }

    private JPanel form() {
        JPanel p = Ui.card();
        p.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.anchor = GridBagConstraints.WEST;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        int row = 0;
        for (Object[] r : new Object[][] {
                {"PASSENGER NAME", nameField}, {"AGE", ageField}, {"GENDER", genderBox}}) {
            c.gridy = row++;
            c.insets = new Insets(6, 0, 2, 0);
            p.add(Ui.fieldLabel((String) r[0]), c);
            c.gridy = row++;
            c.insets = new Insets(0, 0, 4, 0);
            p.add((java.awt.Component) r[1], c);
        }
        c.gridy = row;
        c.insets = new Insets(6, 0, 0, 0);
        p.add(message, c);
        return p;
    }

    private JPanel buttons() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        p.setOpaque(false);
        Ui.AppButton cancel = Ui.button("Cancel", Ui.MUTED);
        Ui.AppButton confirm = Ui.button("Continue to payment", Ui.BLUE);
        cancel.addActionListener(e -> dispose());
        confirm.addActionListener(e -> confirmBooking());
        p.add(cancel);
        p.add(confirm);
        getRootPane().setDefaultButton(confirm);
        return p;
    }

    void confirmBooking() {
        int age;
        try {
            age = Rules.parseInt(ageField.getText(), "Age", 1, 120);
            Rules.validatePassenger(nameField.getText(), age, (String) genderBox.getSelectedItem());
            message.setText(" ");
            PaymentDialog pay = new PaymentDialog(this, flight.getFlightNumber(), flight.getRoute(),
                    flight.getPrice());
            pay.setVisible(true);
            Payment payment = pay.getResult();
            if (payment == null) {
                return; // the passenger went back without paying
            }
            result = repo.book(user.getId(), flight.getId(), nameField.getText(), age,
                    (String) genderBox.getSelectedItem(), payment);
            dispose();
        } catch (AirlineException ex) {
            message.setText(ex.getMessage() + " (Your payment was not taken.)");
            pack();
        }
    }
}
