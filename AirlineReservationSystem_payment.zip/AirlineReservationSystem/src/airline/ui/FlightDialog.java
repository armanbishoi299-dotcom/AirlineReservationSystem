package airline.ui;

import airline.AirlineException;
import airline.data.Repository;
import airline.data.Rules;
import airline.model.Flight;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

/** Form used by the administrator to add a new flight or edit an existing one. */
class FlightDialog extends JDialog {
    private static final long serialVersionUID = 1L;

    private final Repository repo;
    private final Flight existing;

    final JTextField number = Ui.field(14);
    final JTextField source = Ui.field(14);
    final JTextField destination = Ui.field(14);
    final JTextField date = Ui.field(14);
    final JTextField departs = Ui.field(14);
    final JTextField arrives = Ui.field(14);
    final JTextField seats = Ui.field(14);
    final JTextField fare = Ui.field(14);
    private final JLabel message = Ui.label(" ", Font.PLAIN, 13, Ui.RED);
    private boolean saved;

    FlightDialog(JFrame parent, Repository repo, Flight existing) {
        super(parent, existing == null ? "Add flight" : "Edit flight " + existing.getFlightNumber(), true);
        this.repo = repo;
        this.existing = existing;

        if (existing != null) {
            number.setText(existing.getFlightNumber());
            source.setText(existing.getSource());
            destination.setText(existing.getDestination());
            date.setText(existing.getTravelDate().format(Rules.DATE_FMT));
            departs.setText(existing.getDepartureTime().format(Rules.TIME_FMT));
            arrives.setText(existing.getArrivalTime().format(Rules.TIME_FMT));
            seats.setText(String.valueOf(existing.getTotalSeats()));
            fare.setText(String.valueOf((long) existing.getPrice()));
        } else {
            date.setText(java.time.LocalDate.now().plusDays(1).format(Rules.DATE_FMT));
            departs.setText("09:00");
            arrives.setText("11:00");
            seats.setText("60");
        }

        JPanel root = new JPanel(new BorderLayout(0, 12));
        root.setBackground(Ui.BG);
        root.setBorder(BorderFactory.createEmptyBorder(18, 22, 16, 22));
        root.add(Ui.label(existing == null ? "Add a new flight" : "Edit flight", Font.BOLD, 20, Ui.NAVY),
                BorderLayout.NORTH);
        root.add(form(), BorderLayout.CENTER);
        root.add(buttons(), BorderLayout.SOUTH);
        setContentPane(root);
        pack();
        setLocationRelativeTo(parent);
    }

    boolean isSaved() {
        return saved;
    }

    private JPanel form() {
        JPanel p = Ui.card();
        p.setLayout(new GridBagLayout());
        String[] labels = {"FLIGHT NUMBER", "FROM (SOURCE)", "TO (DESTINATION)", "DATE (YYYY-MM-DD)",
                "DEPARTURE (HH:MM)", "ARRIVAL (HH:MM)", "TOTAL SEATS", "FARE (RS.)"};
        JTextField[] fields = {number, source, destination, date, departs, arrives, seats, fare};
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < labels.length; i++) {
            c.gridx = 0;
            c.gridy = i;
            c.weightx = 0;
            c.insets = new Insets(5, 0, 5, 14);
            p.add(Ui.fieldLabel(labels[i]), c);
            c.gridx = 1;
            c.weightx = 1;
            c.insets = new Insets(5, 0, 5, 0);
            p.add(fields[i], c);
        }
        c.gridx = 0;
        c.gridy = labels.length;
        c.gridwidth = 2;
        c.insets = new Insets(8, 0, 0, 0);
        p.add(message, c);
        return p;
    }

    private JPanel buttons() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        p.setOpaque(false);
        Ui.AppButton cancel = Ui.button("Cancel", Ui.MUTED);
        Ui.AppButton save = Ui.button("Save flight", Ui.BLUE);
        cancel.addActionListener(e -> dispose());
        save.addActionListener(e -> save());
        p.add(cancel);
        p.add(save);
        getRootPane().setDefaultButton(save);
        return p;
    }

    void save() {
        try {
            Flight f = existing == null ? new Flight() : existing.copy();
            f.setFlightNumber(number.getText());
            f.setSource(source.getText());
            f.setDestination(destination.getText());
            f.setTravelDate(Rules.parseDate(date.getText(), "Date"));
            f.setDepartureTime(Rules.parseTime(departs.getText(), "Departure time"));
            f.setArrivalTime(Rules.parseTime(arrives.getText(), "Arrival time"));
            f.setTotalSeats(Rules.parseInt(seats.getText(), "Total seats", 1, 500));
            f.setPrice(Rules.parsePrice(fare.getText()));
            if (existing == null) {
                repo.addFlight(f);
            } else {
                repo.updateFlight(f);
            }
            saved = true;
            dispose();
        } catch (AirlineException ex) {
            message.setText(ex.getMessage());
            pack();
        }
    }
}
