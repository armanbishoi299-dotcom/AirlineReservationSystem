package airline.ui;

import airline.AirlineException;
import airline.data.Repository;
import airline.data.Rules;
import airline.model.Booking;
import airline.model.Flight;
import airline.model.Payment;
import airline.model.User;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Passenger window: search flights, book a seat, see bookings, cancel. */
public class PassengerFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    private final Repository repo;
    private final User user;
    private final Runnable onLogout;

    // flights tab
    final JComboBox<String> fromBox = new JComboBox<>();
    final JComboBox<String> toBox = new JComboBox<>();
    final JTextField dateField = Ui.field(10);
    final DefaultTableModel flightModel = Ui.model("Flight", "From", "To", "Date", "Departs", "Arrives",
            "Seats left", "Fare");
    final JTable flightTable = Ui.table(flightModel);
    final JLabel searchInfo = Ui.label(" ", Font.PLAIN, 13, Ui.MUTED);
    private List<Flight> shownFlights = new ArrayList<>();
    private Runnable lastQuery;

    // bookings tab
    final DefaultTableModel bookingModel = Ui.model("PNR", "Flight", "Route", "Travel date", "Passenger",
            "Seat", "Fare", "Status", "Payment");
    final JTable bookingTable = Ui.table(bookingModel);
    final JTextField pnrField = Ui.field(12);
    private List<Booking> myBookings = new ArrayList<>();
    final JTabbedPane tabs = Ui.tabs();

    public PassengerFrame(Repository repo, User user, Runnable onLogout) {
        super("Airline Reservation System - Passenger");
        this.repo = repo;
        this.user = user;
        this.onLogout = onLogout;
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        Ui.AppButton logout = Ui.button("Logout", Ui.MID);
        logout.addActionListener(e -> {
            dispose();
            onLogout.run();
        });
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);
        right.add(Ui.label("Logged in as " + user.getEmail(), Font.PLAIN, 13, new Color(0xC9D5EA)));
        right.add(logout);

        tabs.addTab("Search and book", buildSearchTab());
        tabs.addTab("My bookings", buildBookingsTab());

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Ui.BG);
        root.add(Ui.headerBar("Welcome, " + user.getName(), repo.describe(), right), BorderLayout.NORTH);
        JPanel body = new JPanel(new BorderLayout());
        body.setBorder(BorderFactory.createEmptyBorder(14, 20, 14, 20));
        body.setOpaque(false);
        body.add(tabs, BorderLayout.CENTER);
        root.add(body, BorderLayout.CENTER);
        setContentPane(root);

        setSize(1120, 690);
        setMinimumSize(new Dimension(980, 600));
        setLocationRelativeTo(null);

        loadCities();
        showUpcoming();
        reloadBookings();
    }

    // ------------------------------------------------------------ search tab

    private JPanel buildSearchTab() {
        JPanel tab = new JPanel(new BorderLayout(0, 10));
        tab.setBackground(Ui.BG);
        tab.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));

        fromBox.setEditable(true);
        toBox.setEditable(true);
        Ui.combo(fromBox);
        Ui.combo(toBox);
        fromBox.setPreferredSize(new Dimension(160, 36));
        toBox.setPreferredSize(new Dimension(160, 36));
        dateField.setText(LocalDate.now().plusDays(1).format(Rules.DATE_FMT));

        Ui.AppButton search = Ui.button("Search", Ui.BLUE);
        Ui.AppButton all = Ui.button("All upcoming", Ui.MID);
        search.addActionListener(e -> search());
        all.addActionListener(e -> showUpcoming());

        JPanel bar = Ui.card();
        bar.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 0));
        bar.setBorder(BorderFactory.createEmptyBorder(10, 16, 12, 16));
        bar.add(Ui.fieldLabel("FROM"));
        bar.add(fromBox);
        bar.add(Ui.fieldLabel("TO"));
        bar.add(toBox);
        bar.add(Ui.fieldLabel("DATE"));
        bar.add(dateField);
        bar.add(search);
        bar.add(all);

        Ui.widths(flightTable, 70, 110, 110, 110, 80, 80, 80, 90);
        flightTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && flightTable.getSelectedRow() >= 0) {
                    bookSelected();
                }
            }
        });

        Ui.AppButton book = Ui.button("Book selected flight", Ui.AMBER);
        book.addActionListener(e -> bookSelected());
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setOpaque(false);
        bottom.add(searchInfo, BorderLayout.CENTER);
        bottom.add(book, BorderLayout.EAST);

        tab.add(bar, BorderLayout.NORTH);
        tab.add(Ui.scroll(flightTable), BorderLayout.CENTER);
        tab.add(bottom, BorderLayout.SOUTH);
        return tab;
    }

    private void loadCities() {
        try {
            List<String> cities = repo.cities();
            fromBox.removeAllItems();
            toBox.removeAllItems();
            for (String c : cities) {
                fromBox.addItem(c);
                toBox.addItem(c);
            }
            if (cities.contains("Delhi")) {
                fromBox.setSelectedItem("Delhi");
            }
            if (cities.contains("Mumbai")) {
                toBox.setSelectedItem("Mumbai");
            }
        } catch (AirlineException ex) {
            Ui.error(this, ex.getMessage());
        }
    }

    void search() {
        try {
            String from = Rules.requireText(comboText(fromBox), "From");
            String to = Rules.requireText(comboText(toBox), "To");
            LocalDate date = Rules.parseDate(dateField.getText(), "Date");
            lastQuery = this::search;
            List<Flight> found = repo.searchFlights(from, to, date);
            showFlights(found);
            searchInfo.setForeground(found.isEmpty() ? Ui.RED : Ui.MUTED);
            searchInfo.setText(found.isEmpty()
                    ? "No flights with free seats from " + from + " to " + to + " on "
                    + date.format(Rules.DATE_SHOW) + ". Try another date or \"All upcoming\"."
                    : found.size() + " flight(s) from " + from + " to " + to + " on "
                    + date.format(Rules.DATE_SHOW) + ". Select one and click \"Book selected flight\" (date format yyyy-MM-dd).");
        } catch (AirlineException ex) {
            Ui.error(this, ex.getMessage());
        }
    }

    /** Text currently shown in an editable combo box (typed or selected). */
    private static String comboText(JComboBox<String> box) {
        Object item = box.getEditor().getItem();
        return item == null ? "" : item.toString();
    }

    void showUpcoming() {
        try {
            lastQuery = this::showUpcoming;
            List<Flight> list = repo.upcomingFlights();
            showFlights(list);
            searchInfo.setForeground(Ui.MUTED);
            searchInfo.setText("Showing all " + list.size() + " upcoming flight(s) with free seats.");
        } catch (AirlineException ex) {
            Ui.error(this, ex.getMessage());
        }
    }

    private void showFlights(List<Flight> flights) {
        shownFlights = flights;
        flightModel.setRowCount(0);
        for (Flight f : flights) {
            flightModel.addRow(new Object[] {f.getFlightNumber(), f.getSource(), f.getDestination(),
                    f.getTravelDate().format(Rules.DATE_SHOW), f.getDepartureTime().format(Rules.TIME_FMT),
                    f.getArrivalTime().format(Rules.TIME_FMT), f.getAvailableSeats(), Ui.money(f.getPrice())});
        }
        if (!flights.isEmpty()) {
            flightTable.setRowSelectionInterval(0, 0);
        }
    }

    void bookSelected() {
        int row = flightTable.getSelectedRow();
        if (row < 0 || row >= shownFlights.size()) {
            Ui.info(this, "Please select a flight first.");
            return;
        }
        BookingDialog dialog = new BookingDialog(this, repo, user, shownFlights.get(row));
        dialog.setVisible(true);
        Booking b = dialog.getResult();
        if (b != null) {
            Ui.info(this, "Booking confirmed!\n\nPNR:  " + b.getPnr() + "\nFlight:  " + b.getFlightNumber()
                    + "  " + b.getRoute() + "\nDate:  " + b.getTravelDate().format(Rules.DATE_SHOW)
                    + "\nPassenger:  " + b.getPassengerName() + "\nSeat:  " + b.getSeatNumber()
                    + "\nFare:  " + Ui.money(b.getPrice())
                    + "\nPaid by:  " + b.getPaymentSummary() + (b.getTransactionId() == null ? ""
                    : "\nTransaction ID:  " + b.getTransactionId()));
            reloadBookings();
            if (lastQuery != null) {
                lastQuery.run();
            }
        }
    }

    // ---------------------------------------------------------- bookings tab

    private JPanel buildBookingsTab() {
        JPanel tab = new JPanel(new BorderLayout(0, 10));
        tab.setBackground(Ui.BG);
        tab.setBorder(BorderFactory.createEmptyBorder(12, 0, 0, 0));

        Ui.widths(bookingTable, 90, 60, 170, 100, 130, 45, 85, 90, 130);
        bookingTable.getSelectionModel().addListSelectionListener(e -> {
            int row = bookingTable.getSelectedRow();
            if (!e.getValueIsAdjusting() && row >= 0 && row < myBookings.size()) {
                pnrField.setText(myBookings.get(row).getPnr());
            }
        });

        Ui.AppButton cancel = Ui.button("Cancel booking", Ui.RED);
        Ui.AppButton refresh = Ui.button("Refresh", Ui.MID);
        cancel.addActionListener(e -> cancelBooking());
        refresh.addActionListener(e -> reloadBookings());

        JPanel bar = Ui.card();
        bar.setLayout(new FlowLayout(FlowLayout.LEFT, 12, 0));
        bar.setBorder(BorderFactory.createEmptyBorder(10, 16, 12, 16));
        bar.add(Ui.fieldLabel("PNR TO CANCEL"));
        bar.add(pnrField);
        bar.add(cancel);
        bar.add(Box.createHorizontalStrut(20));
        bar.add(refresh);

        tab.add(Ui.scroll(bookingTable), BorderLayout.CENTER);
        tab.add(bar, BorderLayout.SOUTH);
        return tab;
    }

    void reloadBookings() {
        try {
            myBookings = repo.bookingsForUser(user.getId());
            bookingModel.setRowCount(0);
            for (Booking b : myBookings) {
                bookingModel.addRow(new Object[] {b.getPnr(), b.getFlightNumber(), b.getRoute(),
                        b.getTravelDate().format(Rules.DATE_SHOW), b.getPassengerName(), b.getSeatNumber(),
                        Ui.money(b.getPrice()), b.getStatus(), b.getPaymentSummary()});
            }
        } catch (AirlineException ex) {
            Ui.error(this, ex.getMessage());
        }
    }

    void cancelBooking() {
        String pnr = pnrField.getText().trim();
        if (pnr.isEmpty()) {
            Ui.info(this, "Select a booking in the table or type its PNR.");
            return;
        }
        if (!Ui.confirm(this, "Cancel booking " + pnr.toUpperCase() + "?")) {
            return;
        }
        try {
            Booking b = repo.cancel(pnr, user.getId());
            Ui.info(this, "Booking " + b.getPnr() + " is cancelled and seat " + b.getSeatNumber()
                    + " has been released."
                    + (Payment.REFUNDED.equals(b.getPaymentStatus())
                    ? "\nYour payment of " + Ui.money(b.getPrice()) + " will be refunded to " + b.getPaymentMethod()
                    + " (" + b.getPaymentRef() + ")." : ""));
            pnrField.setText("");
            reloadBookings();
            if (lastQuery != null) {
                lastQuery.run();
            }
        } catch (AirlineException ex) {
            Ui.error(this, ex.getMessage());
        }
    }
}
