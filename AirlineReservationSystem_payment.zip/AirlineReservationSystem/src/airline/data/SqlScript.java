package airline.data;

import java.util.ArrayList;
import java.util.List;

/** Splits a .sql file into single statements (comment lines starting with -- are ignored). */
final class SqlScript {
    private SqlScript() { }

    static List<String> statements(String script) {
        StringBuilder cleaned = new StringBuilder();
        for (String line : script.split("\\R")) {
            if (!line.trim().startsWith("--")) {
                cleaned.append(line).append('\n');
            }
        }
        List<String> out = new ArrayList<>();
        for (String part : cleaned.toString().split(";")) {
            String sql = part.trim();
            if (!sql.isEmpty()) {
                out.add(sql);
            }
        }
        return out;
    }
}
