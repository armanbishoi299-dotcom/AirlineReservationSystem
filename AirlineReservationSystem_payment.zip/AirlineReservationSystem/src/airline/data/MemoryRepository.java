package airline.data;

import airline.AirlineException;
import airline.model.Booking;
import airline.model.Payment;
import airline.model.Flight;
import airline.model.User;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * Demo data source that keeps everything in memory (nothing is saved when the program closes).
 * It follows exactly the same rules as {@link JdbcRepository}, so the whole application can be
 * shown on a computer that has no MySQL installed.
 */
public class MemoryRepository implements Repository {

    private static final class Account {
        final User user;
        final String password;

        Account(User user, String password) {
            this.user = user;
            this.password = password;
        }
    }

    private final Map<Integer, Account> users = new LinkedHashMap<>();
    private final Map<Integer, Flight> flights = new LinkedHashMap<>();
    private final Map<Integer, Booking> bookings = new LinkedHashMap<>();
    private int nextUserId = 1;
    private int nextFlightId = 1;
    private int nextBookingId = 1;

    @Override
    public synchronized void init() {
        if (users.isEmpty()) {
            User demo = new User(nextUserId++, SampleData.DEMO_NAME, SampleData.DEMO_EMAIL, SampleData.DEMO_PHONE);
            users.put(demo.getId(), new Account(demo, SampleData.DEMO_PASSWORD));
        }
        if (flights.isEmpty()) {
            for (Flight f : SampleData.flights()) {
                f.setId(nextFlightId++);
                flights.put(f.getId(), f);
            }
        }
    }

    @Override
    public String describe() {
        return "DEMO MODE  (in-memory data, not saved)";
    }

    // ----------------------------------------------------------- passenger

    @Override
    public synchronized User register(String name, String email, String password, String phone)
            throws AirlineException {
        Rules.validateRegistration(name, email, password, phone);
        String clean = Rules.normalizeEmail(email);
        for (Account a : users.values()) {
            if (a.user.getEmail().equals(clean)) {
                throw new AirlineException("An account with this email already exists.");
            }
        }
        User u = new User(nextUserId++, name.trim(), clean, phone.trim());
        users.put(u.getId(), new Account(u, password));
        return u;
    }

    @Override
    public synchronized User login(String email, String password) {
        if (email == null || password == null) {
            return null;
        }
        String clean = email.trim().toLowerCase(Locale.ROOT);
        for (Account a : users.values()) {
            if (a.user.getEmail().equals(clean) && a.password.equals(password)) {
                return a.user;
            }
        }
        return null;
    }

    @Override
    public synchronized List<String> cities() {
        Set<String> set = new TreeSet<>();
        for (Flight f : flights.values()) {
            set.add(f.getSource());
            set.add(f.getDestination());
        }
        return new ArrayList<>(set);
    }

    @Override
    public synchronized List<Flight> searchFlights(String source, String destination, LocalDate date) {
        List<Flight> out = new ArrayList<>();
        for (Flight f : flights.values()) {
            if (f.getSource().equalsIgnoreCase(source.trim())
                    && f.getDestination().equalsIgnoreCase(destination.trim())
                    && f.getTravelDate().equals(date) && f.getAvailableSeats() > 0) {
                out.add(f.copy());
            }
        }
        out.sort(Comparator.comparing(Flight::getDepartureTime));
        return out;
    }

    @Override
    public synchronized List<Flight> upcomingFlights() {
        List<Flight> out = new ArrayList<>();
        LocalDate today = LocalDate.now();
        for (Flight f : flights.values()) {
            if (!f.getTravelDate().isBefore(today) && f.getAvailableSeats() > 0) {
                out.add(f.copy());
            }
        }
        out.sort(Comparator.comparing(Flight::getTravelDate).thenComparing(Flight::getDepartureTime));
        return out;
    }

    @Override
    public synchronized Booking book(int userId, int flightId, String passengerName, int age, String gender,
                                     Payment payment) throws AirlineException {
        Rules.validatePassenger(passengerName, age, gender);
        Flight flight = flights.get(flightId);
        if (flight == null) {
            throw new AirlineException("This flight no longer exists.");
        }
        if (flight.getTravelDate().isBefore(LocalDate.now())) {
            throw new AirlineException("This flight has already departed.");
        }
        if (flight.getAvailableSeats() <= 0) {
            throw new AirlineException("Sorry, no seats are available on this flight.");
        }
        Set<Integer> taken = new HashSet<>();
        for (Booking b : bookings.values()) {
            if (b.getFlightId() == flightId && Rules.CONFIRMED.equals(b.getStatus())) {
                taken.add(b.getSeatNumber());
            }
        }
        int seat = Rules.nextFreeSeat(taken, flight.getTotalSeats());
        if (seat < 0) {
            throw new AirlineException("Sorry, no seats are available on this flight.");
        }
        String pnr;
        do {
            pnr = Rules.newPnr();
        } while (pnrExists(pnr));

        Account owner = users.get(userId);
        Booking b = new Booking();
        b.setId(nextBookingId++);
        b.setPnr(pnr);
        b.setUserId(userId);
        b.setFlightId(flightId);
        b.setPassengerName(passengerName.trim());
        b.setPassengerAge(age);
        b.setPassengerGender(gender);
        b.setSeatNumber(seat);
        b.setBookingDate(LocalDate.now());
        b.setStatus(Rules.CONFIRMED);
        applyPayment(b, payment);
        b.setUserEmail(owner == null ? "" : owner.user.getEmail());
        fillFlightDetails(b, flight);
        bookings.put(b.getId(), b);
        flight.setAvailableSeats(flight.getAvailableSeats() - 1);
        return copy(b);
    }

    @Override
    public synchronized List<Booking> bookingsForUser(int userId) {
        List<Booking> out = new ArrayList<>();
        for (Booking b : bookings.values()) {
            if (b.getUserId() == userId) {
                out.add(copy(b));
            }
        }
        out.sort(Comparator.comparingInt(Booking::getId).reversed());
        return out;
    }

    @Override
    public synchronized Booking cancel(String pnr, int userId) throws AirlineException {
        String code = Rules.requireText(pnr, "PNR").toUpperCase(Locale.ROOT);
        for (Booking b : bookings.values()) {
            if (b.getPnr().equals(code) && b.getUserId() == userId) {
                if (!Rules.CONFIRMED.equals(b.getStatus())) {
                    throw new AirlineException("Booking " + code + " is already cancelled.");
                }
                b.setStatus(Rules.CANCELLED);
                if (Payment.PAID.equals(b.getPaymentStatus())) {
                    b.setPaymentStatus(Payment.REFUNDED);
                }
                Flight f = flights.get(b.getFlightId());
                if (f != null) {
                    f.setAvailableSeats(f.getAvailableSeats() + 1);
                }
                return copy(b);
            }
        }
        throw new AirlineException("No booking with PNR " + code + " was found for your account.");
    }

    // --------------------------------------------------------------- admin

    @Override
    public synchronized List<Flight> allFlights() {
        List<Flight> out = new ArrayList<>();
        for (Flight f : flights.values()) {
            out.add(f.copy());
        }
        out.sort(Comparator.comparing(Flight::getTravelDate).thenComparing(Flight::getDepartureTime)
                .thenComparing(Flight::getFlightNumber));
        return out;
    }

    @Override
    public synchronized Flight addFlight(Flight flight) throws AirlineException {
        Rules.validateFlight(flight);
        Flight saved = flight.copy();
        saved.setId(nextFlightId++);
        saved.setAvailableSeats(saved.getTotalSeats());
        flights.put(saved.getId(), saved);
        return saved.copy();
    }

    @Override
    public synchronized void updateFlight(Flight flight) throws AirlineException {
        Rules.validateFlight(flight);
        Flight existing = flights.get(flight.getId());
        if (existing == null) {
            throw new AirlineException("This flight no longer exists.");
        }
        int confirmed = confirmedCount(flight.getId());
        if (flight.getTotalSeats() < confirmed) {
            throw new AirlineException("Total seats cannot be less than the " + confirmed
                    + " seats already booked.");
        }
        existing.setFlightNumber(flight.getFlightNumber());
        existing.setSource(flight.getSource());
        existing.setDestination(flight.getDestination());
        existing.setTravelDate(flight.getTravelDate());
        existing.setDepartureTime(flight.getDepartureTime());
        existing.setArrivalTime(flight.getArrivalTime());
        existing.setTotalSeats(flight.getTotalSeats());
        existing.setAvailableSeats(flight.getTotalSeats() - confirmed);
        existing.setPrice(flight.getPrice());
        for (Booking b : bookings.values()) {
            if (b.getFlightId() == existing.getId()) {
                fillFlightDetails(b, existing);
            }
        }
    }

    @Override
    public synchronized void deleteFlight(int flightId) throws AirlineException {
        if (!flights.containsKey(flightId)) {
            throw new AirlineException("This flight no longer exists.");
        }
        for (Booking b : bookings.values()) {
            if (b.getFlightId() == flightId) {
                throw new AirlineException("This flight has bookings and cannot be deleted.");
            }
        }
        flights.remove(flightId);
    }

    @Override
    public synchronized List<Booking> allBookings() {
        List<Booking> out = new ArrayList<>();
        for (Booking b : bookings.values()) {
            out.add(copy(b));
        }
        out.sort(Comparator.comparingInt(Booking::getId).reversed());
        return out;
    }

    // ------------------------------------------------------------- helpers

    private boolean pnrExists(String pnr) {
        for (Booking b : bookings.values()) {
            if (b.getPnr().equals(pnr)) {
                return true;
            }
        }
        return false;
    }

    private int confirmedCount(int flightId) {
        int n = 0;
        for (Booking b : bookings.values()) {
            if (b.getFlightId() == flightId && Rules.CONFIRMED.equals(b.getStatus())) {
                n++;
            }
        }
        return n;
    }

    private static void applyPayment(Booking b, Payment p) {
        Payment pay = p == null ? Payment.unpaid() : p;
        b.setPaymentMethod(pay.getMethod());
        b.setPaymentRef(pay.getReference());
        b.setTransactionId(pay.getTransactionId());
        b.setPaymentStatus(pay.getStatus());
    }

    private static void fillFlightDetails(Booking b, Flight f) {
        b.setFlightNumber(f.getFlightNumber());
        b.setSource(f.getSource());
        b.setDestination(f.getDestination());
        b.setTravelDate(f.getTravelDate());
        b.setPrice(f.getPrice());
    }

    private static Booking copy(Booking s) {
        Booking b = new Booking();
        b.setId(s.getId());
        b.setPnr(s.getPnr());
        b.setUserId(s.getUserId());
        b.setFlightId(s.getFlightId());
        b.setPassengerName(s.getPassengerName());
        b.setPassengerAge(s.getPassengerAge());
        b.setPassengerGender(s.getPassengerGender());
        b.setSeatNumber(s.getSeatNumber());
        b.setBookingDate(s.getBookingDate());
        b.setStatus(s.getStatus());
        b.setFlightNumber(s.getFlightNumber());
        b.setSource(s.getSource());
        b.setDestination(s.getDestination());
        b.setTravelDate(s.getTravelDate());
        b.setPrice(s.getPrice());
        b.setUserEmail(s.getUserEmail());
        b.setPaymentMethod(s.getPaymentMethod());
        b.setPaymentRef(s.getPaymentRef());
        b.setTransactionId(s.getTransactionId());
        b.setPaymentStatus(s.getPaymentStatus());
        return b;
    }
}
