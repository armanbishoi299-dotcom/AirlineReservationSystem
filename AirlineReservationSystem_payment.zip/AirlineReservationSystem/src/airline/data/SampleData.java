package airline.data;

import airline.model.Flight;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/** Demonstration data: flights on the next few days, and one demo passenger. */
public final class SampleData {
    public static final String DEMO_NAME = "Demo Passenger";
    public static final String DEMO_EMAIL = "demo@airline.com";
    public static final String DEMO_PASSWORD = "demo123";
    public static final String DEMO_PHONE = "9876543210";

    private SampleData() { }

    private static Flight f(String no, String from, String to, int dayOffset, String dep, String arr,
                            int seats, double price) {
        return new Flight(0, no, from, to, LocalDate.now().plusDays(dayOffset), LocalTime.parse(dep),
                LocalTime.parse(arr), seats, seats, price);
    }

    public static List<Flight> flights() {
        List<Flight> list = new ArrayList<>();
        list.add(f("AR101", "Delhi", "Mumbai", 1, "06:00", "08:10", 60, 4850));
        list.add(f("AR102", "Delhi", "Mumbai", 1, "13:30", "15:40", 60, 5400));
        list.add(f("AR103", "Mumbai", "Delhi", 1, "09:15", "11:25", 60, 4950));
        list.add(f("AR201", "Delhi", "Bengaluru", 1, "07:45", "10:30", 80, 6200));
        list.add(f("AR202", "Bengaluru", "Delhi", 2, "18:20", "21:05", 80, 6350));
        list.add(f("AR301", "Delhi", "Kolkata", 2, "10:00", "12:15", 50, 5100));
        list.add(f("AR302", "Kolkata", "Delhi", 3, "16:40", "18:55", 50, 5250));
        list.add(f("AR401", "Mumbai", "Chennai", 1, "11:10", "13:05", 70, 4300));
        list.add(f("AR402", "Chennai", "Mumbai", 2, "15:25", "17:20", 70, 4400));
        list.add(f("AR501", "Delhi", "Hyderabad", 2, "08:30", "10:55", 60, 5600));
        list.add(f("AR502", "Hyderabad", "Delhi", 3, "20:00", "22:25", 60, 5700));
        list.add(f("AR601", "Mumbai", "Goa", 3, "12:00", "13:10", 40, 3200));
        return list;
    }
}
