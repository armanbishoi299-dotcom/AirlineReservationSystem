package airline.data;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/** Settings read from config/db.properties (database location, login, administrator account). */
public final class Config {
    private final Properties props = new Properties();

    private Config() {
        props.setProperty("db.host", "localhost");
        props.setProperty("db.port", "3306");
        props.setProperty("db.name", "airline_db");
        props.setProperty("db.user", "root");
        props.setProperty("db.password", "");
        props.setProperty("admin.username", "admin");
        props.setProperty("admin.password", "admin123");
    }

    /** Loads the file if it exists; missing keys keep their defaults. */
    public static Config load(String path) {
        Config c = new Config();
        try (InputStream in = new FileInputStream(path)) {
            c.props.load(in);
        } catch (IOException ignored) {
            // no file: defaults are used
        }
        return c;
    }

    public static Config defaults() {
        return new Config();
    }

    private String get(String key) {
        return props.getProperty(key, "").trim();
    }

    public String host() { return get("db.host"); }
    public String port() { return get("db.port"); }
    public String dbName() { return get("db.name"); }
    public String dbUser() { return get("db.user"); }
    public String dbPassword() { return props.getProperty("db.password", ""); }
    public String adminUser() { return get("admin.username"); }
    public String adminPassword() { return props.getProperty("admin.password", ""); }

    private static final String OPTIONS = "useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    /** URL of the airline database itself. */
    public String jdbcUrl() {
        return "jdbc:mysql://" + host() + ":" + port() + "/" + dbName() + "?" + OPTIONS;
    }

    /** URL of the MySQL server without a database (used once, to create the database). */
    public String serverUrl() {
        return "jdbc:mysql://" + host() + ":" + port() + "/?" + OPTIONS;
    }
}
