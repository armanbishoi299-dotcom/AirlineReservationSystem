package airline.data;

import airline.AirlineException;
import airline.model.Payment;

import java.security.SecureRandom;
import java.time.YearMonth;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * A simulated payment gateway for the demonstration. It validates what the passenger typed,
 * pretends to contact a bank and returns a {@link Payment} with a transaction id.
 * No real money moves, and card numbers / CVV codes are checked and then thrown away:
 * only the last four digits are kept.
 *
 * Test card: 4111 1111 1111 1111 succeeds, 4000 0000 0000 0002 is declined by the "bank".
 */
public final class PaymentService {
    public static final String[] BANKS = {"State Bank of India", "HDFC Bank", "ICICI Bank", "Axis Bank",
            "Punjab National Bank", "Kotak Mahindra Bank"};
    public static final String[] WALLETS = {"Paytm", "PhonePe", "Amazon Pay", "Mobikwik"};

    private static final String ID_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789";
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final Pattern UPI_ID = Pattern.compile("^[A-Za-z0-9._-]{2,}@[A-Za-z][A-Za-z0-9]{1,}$");
    private static final Pattern MOBILE = Pattern.compile("^[0-9]{10}$");
    private static final Pattern EXPIRY = Pattern.compile("^(0[1-9]|1[0-2])\\s*/\\s*([0-9]{2})$");
    private static final String DECLINED_CARD = "4000000000000002";

    private PaymentService() { }

    public static Payment payUpi(String upiId) throws AirlineException {
        String id = Rules.requireText(upiId, "UPI ID").toLowerCase(Locale.ROOT);
        if (!UPI_ID.matcher(id).matches()) {
            throw new AirlineException("Please enter a valid UPI ID, for example name@bank.");
        }
        return success(Payment.UPI, id);
    }

    public static Payment payCard(String holder, String number, String expiry, String cvv) throws AirlineException {
        Rules.requireText(holder, "Name on card");
        String digits = Rules.requireText(number, "Card number").replaceAll("[\\s-]", "");
        if (!digits.matches("[0-9]{13,19}") || !luhn(digits)) {
            throw new AirlineException("The card number is not valid.");
        }
        java.util.regex.Matcher m = EXPIRY.matcher(Rules.requireText(expiry, "Expiry").trim());
        if (!m.matches()) {
            throw new AirlineException("Expiry must look like MM/YY.");
        }
        YearMonth exp = YearMonth.of(2000 + Integer.parseInt(m.group(2)), Integer.parseInt(m.group(1)));
        if (exp.isBefore(YearMonth.now())) {
            throw new AirlineException("This card has expired.");
        }
        if (cvv == null || !cvv.matches("[0-9]{3,4}")) {
            throw new AirlineException("CVV must be 3 or 4 digits.");
        }
        if (DECLINED_CARD.equals(digits)) {
            throw new AirlineException("Payment declined by the bank. Please try another card or method.");
        }
        return success(Payment.CARD, "xxxx " + digits.substring(digits.length() - 4));
    }

    public static Payment payNetBanking(String bank) throws AirlineException {
        return success(Payment.NET_BANKING, Rules.requireText(bank, "Bank"));
    }

    public static Payment payWallet(String wallet, String mobile) throws AirlineException {
        String w = Rules.requireText(wallet, "Wallet");
        if (mobile == null || !MOBILE.matcher(mobile.trim()).matches()) {
            throw new AirlineException("Wallet mobile number must be 10 digits.");
        }
        return success(Payment.WALLET, w + " xxxxxx" + mobile.trim().substring(6));
    }

    private static Payment success(String method, String reference) {
        StringBuilder sb = new StringBuilder("TXN");
        for (int i = 0; i < 10; i++) {
            sb.append(ID_ALPHABET.charAt(RANDOM.nextInt(ID_ALPHABET.length())));
        }
        return new Payment(method, reference, sb.toString(), Payment.PAID);
    }

    /** Standard Luhn check-digit test used by real card numbers. */
    static boolean luhn(String digits) {
        int sum = 0;
        boolean dbl = false;
        for (int i = digits.length() - 1; i >= 0; i--) {
            int d = digits.charAt(i) - '0';
            if (dbl) {
                d *= 2;
                if (d > 9) {
                    d -= 9;
                }
            }
            sum += d;
            dbl = !dbl;
        }
        return sum % 10 == 0;
    }
}
