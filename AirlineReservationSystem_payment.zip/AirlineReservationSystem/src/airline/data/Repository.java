package airline.data;

import airline.AirlineException;
import airline.model.Booking;
import airline.model.Flight;
import airline.model.Payment;
import airline.model.User;

import java.time.LocalDate;
import java.util.List;

/**
 * Everything the screens need from the data layer.
 * Implemented by {@link JdbcRepository} (MySQL) and {@link MemoryRepository} (demo mode).
 */
public interface Repository {

    /** Creates tables and sample data if they are missing; checks the connection. */
    void init() throws AirlineException;

    /** Short text describing the data source, for the status line. */
    String describe();

    // ---- passenger ----
    User register(String name, String email, String password, String phone) throws AirlineException;

    /** Returns the user, or null when the email/password pair is wrong. */
    User login(String email, String password) throws AirlineException;

    List<String> cities() throws AirlineException;

    /** Flights on the given date with at least one free seat. */
    List<Flight> searchFlights(String source, String destination, LocalDate date) throws AirlineException;

    /** Every flight from today onward that still has free seats. */
    List<Flight> upcomingFlights() throws AirlineException;

    /** Books a seat without a payment step (payment status stays "Unpaid"). */
    default Booking book(int userId, int flightId, String passengerName, int age, String gender)
            throws AirlineException {
        return book(userId, flightId, passengerName, age, gender, Payment.unpaid());
    }

    /** Books a seat and stores the (already successful) payment details with the booking. */
    Booking book(int userId, int flightId, String passengerName, int age, String gender, Payment payment)
            throws AirlineException;

    List<Booking> bookingsForUser(int userId) throws AirlineException;

    /** Cancels a confirmed booking of this user, gives the seat back and marks a paid fare as Refunded. */
    Booking cancel(String pnr, int userId) throws AirlineException;

    // ---- administrator ----
    List<Flight> allFlights() throws AirlineException;

    Flight addFlight(Flight flight) throws AirlineException;

    void updateFlight(Flight flight) throws AirlineException;

    void deleteFlight(int flightId) throws AirlineException;

    List<Booking> allBookings() throws AirlineException;
}
