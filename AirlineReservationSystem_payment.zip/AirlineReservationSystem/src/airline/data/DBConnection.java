package airline.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * The single, reusable JDBC connection class of the project.
 * Every database operation obtains its connection here, so the URL, user name and
 * password are kept in one place (config/db.properties).
 */
public final class DBConnection {
    private final Config config;

    public DBConnection(Config config) {
        this.config = config;
    }

    /** Connection to the airline database. */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(config.jdbcUrl(), config.dbUser(), config.dbPassword());
    }

    /** Connection to the MySQL server only (no database selected yet). */
    public Connection getServerConnection() throws SQLException {
        return DriverManager.getConnection(config.serverUrl(), config.dbUser(), config.dbPassword());
    }

    public Config getConfig() {
        return config;
    }
}
