package airline.data;

import airline.AirlineException;
import airline.model.Booking;
import airline.model.Payment;
import airline.model.Flight;
import airline.model.User;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * MySQL data layer. All access goes through JDBC with PreparedStatement,
 * so user input is never pasted into SQL text.
 * Booking and cancellation run inside a transaction (commit / rollback).
 */
public class JdbcRepository implements Repository {

    // ------------------------------------------------------------------ SQL
    private static final String FLIGHT_COLUMNS =
            "flight_id, flight_number, source, destination, travel_date, departure_time, arrival_time, "
                    + "total_seats, available_seats, price";

    private static final String SQL_INSERT_USER =
            "INSERT INTO Users (name, email, password, phone) VALUES (?, ?, ?, ?)";
    private static final String SQL_LOGIN =
            "SELECT user_id, name, email, phone FROM Users WHERE email = ? AND password = ?";
    private static final String SQL_USER_EXISTS =
            "SELECT COUNT(*) FROM Users WHERE email = ?";
    private static final String SQL_CITIES =
            "SELECT source AS city FROM Flights UNION SELECT destination FROM Flights ORDER BY city";
    private static final String SQL_SEARCH =
            "SELECT " + FLIGHT_COLUMNS + " FROM Flights "
                    + "WHERE LOWER(source) = ? AND LOWER(destination) = ? AND travel_date = ? "
                    + "AND available_seats > 0 ORDER BY departure_time";
    private static final String SQL_UPCOMING =
            "SELECT " + FLIGHT_COLUMNS + " FROM Flights "
                    + "WHERE travel_date >= ? AND available_seats > 0 ORDER BY travel_date, departure_time";
    private static final String SQL_ALL_FLIGHTS =
            "SELECT " + FLIGHT_COLUMNS + " FROM Flights ORDER BY travel_date, departure_time, flight_number";
    private static final String SQL_FLIGHT_COUNT =
            "SELECT COUNT(*) FROM Flights";
    private static final String SQL_INSERT_FLIGHT =
            "INSERT INTO Flights (flight_number, source, destination, travel_date, departure_time, arrival_time, "
                    + "total_seats, available_seats, price) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SQL_LOCK_FLIGHT =
            "SELECT " + FLIGHT_COLUMNS + " FROM Flights WHERE flight_id = ? FOR UPDATE";
    private static final String SQL_TAKEN_SEATS =
            "SELECT seat_number FROM Bookings WHERE flight_id = ? AND status = 'Confirmed'";
    private static final String SQL_CONFIRMED_COUNT =
            "SELECT COUNT(*) FROM Bookings WHERE flight_id = ? AND status = 'Confirmed'";
    private static final String SQL_PNR_EXISTS =
            "SELECT COUNT(*) FROM Bookings WHERE pnr = ?";
    private static final String SQL_INSERT_BOOKING =
            "INSERT INTO Bookings (pnr, user_id, flight_id, passenger_name, passenger_age, passenger_gender, "
                    + "seat_number, booking_date, status, payment_method, payment_ref, txn_id, payment_status) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String SQL_SEATS_MINUS =
            "UPDATE Flights SET available_seats = available_seats - 1 WHERE flight_id = ? AND available_seats > 0";
    private static final String SQL_SEATS_PLUS =
            "UPDATE Flights SET available_seats = available_seats + 1 WHERE flight_id = ?";
    private static final String SQL_UPDATE_FLIGHT =
            "UPDATE Flights SET flight_number = ?, source = ?, destination = ?, travel_date = ?, "
                    + "departure_time = ?, arrival_time = ?, total_seats = ?, available_seats = ?, price = ? "
                    + "WHERE flight_id = ?";
    private static final String SQL_DELETE_FLIGHT =
            "DELETE FROM Flights WHERE flight_id = ?";
    private static final String SQL_FIND_BOOKING =
            "SELECT booking_id, flight_id, status FROM Bookings WHERE pnr = ? AND user_id = ? FOR UPDATE";
    private static final String SQL_CANCEL_BOOKING =
            "UPDATE Bookings SET status = 'Cancelled', payment_status = "
                    + "CASE WHEN payment_status = 'Paid' THEN 'Refunded' ELSE payment_status END WHERE booking_id = ?";
    private static final String BOOKING_SELECT =
            "SELECT b.booking_id, b.pnr, b.user_id, b.flight_id, b.passenger_name, b.passenger_age, "
                    + "b.passenger_gender, b.seat_number, b.booking_date, b.status, "
                    + "b.payment_method, b.payment_ref, b.txn_id, b.payment_status, "
                    + "f.flight_number, f.source, f.destination, f.travel_date, f.price, u.email "
                    + "FROM Bookings b JOIN Flights f ON b.flight_id = f.flight_id "
                    + "JOIN Users u ON b.user_id = u.user_id ";
    private static final String SQL_BOOKINGS_OF_USER =
            BOOKING_SELECT + "WHERE b.user_id = ? ORDER BY b.booking_id DESC";
    private static final String SQL_BOOKING_BY_ID =
            BOOKING_SELECT + "WHERE b.booking_id = ?";
    private static final String SQL_ALL_BOOKINGS =
            BOOKING_SELECT + "ORDER BY b.booking_id DESC";

    // ---------------------------------------------------------------- state
    private final DBConnection db;

    public JdbcRepository(DBConnection db) {
        this.db = db;
    }

    @Override
    public String describe() {
        Config c = db.getConfig();
        return "MySQL  " + c.host() + ":" + c.port() + "/" + c.dbName();
    }

    // ------------------------------------------------------------- set-up

    /** Upgrades a Bookings table created before the payment feature existed. */
    private static void addPaymentColumns(Statement st) throws SQLException {
        String[][] columns = {{"payment_method", "VARCHAR(20) NULL"}, {"payment_ref", "VARCHAR(60) NULL"},
                {"txn_id", "VARCHAR(20) NULL"}, {"payment_status", "VARCHAR(12) NOT NULL DEFAULT 'Unpaid'"}};
        for (String[] col : columns) {
            try {
                st.execute("ALTER TABLE Bookings ADD COLUMN " + col[0] + " " + col[1]);
            } catch (SQLException e) {
                if (e.getErrorCode() != 1060) { // 1060 = column already exists
                    throw e;
                }
            }
        }
    }

    @Override
    public void init() throws AirlineException {
        String dbName = db.getConfig().dbName();
        if (!dbName.matches("[A-Za-z0-9_]+")) {
            throw new AirlineException("db.name may only contain letters, digits and underscore.");
        }
        try (Connection server = db.getServerConnection(); Statement st = server.createStatement()) {
            st.execute("CREATE DATABASE IF NOT EXISTS `" + dbName + "`");
        } catch (SQLException e) {
            throw connectionProblem(e);
        }
        try (Connection c = db.getConnection(); Statement st = c.createStatement()) {
            for (String sql : SqlScript.statements(readSchema())) {
                String upper = sql.toUpperCase(Locale.ROOT);
                if (upper.startsWith("CREATE DATABASE") || upper.startsWith("USE ")) {
                    continue; // the database was created above and is already selected
                }
                st.execute(sql);
            }
            addPaymentColumns(st);
            seedIfEmpty(c);
        } catch (SQLException e) {
            throw fail("Could not prepare the database", e);
        }
    }

    private String readSchema() throws AirlineException {
        Path file = Paths.get("sql", "schema.sql");
        try {
            if (Files.exists(file)) {
                return new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
            }
            try (java.io.InputStream in = JdbcRepository.class.getResourceAsStream("/schema.sql")) {
                if (in != null) {
                    java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                    byte[] chunk = new byte[4096];
                    int n;
                    while ((n = in.read(chunk)) > 0) {
                        buffer.write(chunk, 0, n);
                    }
                    return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
                }
            }
        } catch (IOException e) {
            throw new AirlineException("Could not read sql/schema.sql: " + e.getMessage(), e);
        }
        throw new AirlineException("sql/schema.sql was not found. Start the program from the project folder.");
    }

    private void seedIfEmpty(Connection c) throws SQLException {
        if (count(c, SQL_USER_EXISTS, SampleData.DEMO_EMAIL) == 0) {
            try (PreparedStatement ps = c.prepareStatement(SQL_INSERT_USER)) {
                ps.setString(1, SampleData.DEMO_NAME);
                ps.setString(2, SampleData.DEMO_EMAIL);
                ps.setString(3, SampleData.DEMO_PASSWORD);
                ps.setString(4, SampleData.DEMO_PHONE);
                ps.executeUpdate();
            }
        }
        if (count(c, SQL_FLIGHT_COUNT, null) == 0) {
            try (PreparedStatement ps = c.prepareStatement(SQL_INSERT_FLIGHT)) {
                for (Flight f : SampleData.flights()) {
                    bindFlight(ps, f, f.getTotalSeats());
                    ps.addBatch();
                }
                ps.executeBatch();
            }
        }
    }

    private int count(Connection c, String sql, String arg) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            if (arg != null) {
                ps.setString(1, arg);
            }
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    // ----------------------------------------------------------- passenger

    @Override
    public User register(String name, String email, String password, String phone) throws AirlineException {
        Rules.validateRegistration(name, email, password, phone);
        String cleanEmail = Rules.normalizeEmail(email);
        try (Connection c = db.getConnection();
             PreparedStatement ps = c.prepareStatement(SQL_INSERT_USER, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name.trim());
            ps.setString(2, cleanEmail);
            ps.setString(3, password);
            ps.setString(4, phone.trim());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return new User(keys.getInt(1), name.trim(), cleanEmail, phone.trim());
            }
        } catch (SQLException e) {
            if (isConstraintViolation(e)) {
                throw new AirlineException("An account with this email already exists.", e);
            }
            throw fail("Registration failed", e);
        }
    }

    @Override
    public User login(String email, String password) throws AirlineException {
        if (email == null || email.trim().isEmpty() || password == null || password.isEmpty()) {
            return null;
        }
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_LOGIN)) {
            ps.setString(1, email.trim().toLowerCase(Locale.ROOT));
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new User(rs.getInt("user_id"), rs.getString("name"), rs.getString("email"),
                            rs.getString("phone"));
                }
                return null;
            }
        } catch (SQLException e) {
            throw fail("Login failed", e);
        }
    }

    @Override
    public List<String> cities() throws AirlineException {
        List<String> cities = new ArrayList<>();
        try (Connection c = db.getConnection();
             PreparedStatement ps = c.prepareStatement(SQL_CITIES);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                cities.add(rs.getString(1));
            }
        } catch (SQLException e) {
            throw fail("Could not load cities", e);
        }
        return cities;
    }

    @Override
    public List<Flight> searchFlights(String source, String destination, LocalDate date) throws AirlineException {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_SEARCH)) {
            ps.setString(1, source.trim().toLowerCase(Locale.ROOT));
            ps.setString(2, destination.trim().toLowerCase(Locale.ROOT));
            ps.setDate(3, Date.valueOf(date));
            return readFlights(ps);
        } catch (SQLException e) {
            throw fail("Flight search failed", e);
        }
    }

    @Override
    public List<Flight> upcomingFlights() throws AirlineException {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_UPCOMING)) {
            ps.setDate(1, Date.valueOf(LocalDate.now()));
            return readFlights(ps);
        } catch (SQLException e) {
            throw fail("Could not load flights", e);
        }
    }

    @Override
    public Booking book(int userId, int flightId, String passengerName, int age, String gender,
                        Payment payment) throws AirlineException {
        Rules.validatePassenger(passengerName, age, gender);
        try (Connection c = db.getConnection()) {
            try {
                c.setAutoCommit(false);

                Flight flight = lockFlight(c, flightId);
                if (flight == null) {
                    throw new AirlineException("This flight no longer exists.");
                }
                if (flight.getTravelDate().isBefore(LocalDate.now())) {
                    throw new AirlineException("This flight has already departed.");
                }
                if (flight.getAvailableSeats() <= 0) {
                    throw new AirlineException("Sorry, no seats are available on this flight.");
                }

                int seat = Rules.nextFreeSeat(takenSeats(c, flightId), flight.getTotalSeats());
                if (seat < 0) {
                    throw new AirlineException("Sorry, no seats are available on this flight.");
                }
                String pnr = uniquePnr(c);

                try (PreparedStatement ps = c.prepareStatement(SQL_INSERT_BOOKING, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, pnr);
                    ps.setInt(2, userId);
                    ps.setInt(3, flightId);
                    ps.setString(4, passengerName.trim());
                    ps.setInt(5, age);
                    ps.setString(6, gender);
                    ps.setInt(7, seat);
                    ps.setDate(8, Date.valueOf(LocalDate.now()));
                    ps.setString(9, Rules.CONFIRMED);
                    Payment pay = payment == null ? Payment.unpaid() : payment;
                    ps.setString(10, pay.getMethod());
                    ps.setString(11, pay.getReference());
                    ps.setString(12, pay.getTransactionId());
                    ps.setString(13, pay.getStatus());
                    ps.executeUpdate();
                    int bookingId;
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        keys.next();
                        bookingId = keys.getInt(1);
                    }
                    try (PreparedStatement dec = c.prepareStatement(SQL_SEATS_MINUS)) {
                        dec.setInt(1, flightId);
                        if (dec.executeUpdate() != 1) {
                            throw new AirlineException("Sorry, the last seat was just taken.");
                        }
                    }
                    Booking booking = loadBooking(c, bookingId);
                    c.commit();
                    return booking;
                }
            } catch (AirlineException | SQLException | RuntimeException e) {
                rollbackQuietly(c);
                throw e;
            }
        } catch (SQLException e) {
            throw fail("Booking failed", e);
        }
    }

    @Override
    public List<Booking> bookingsForUser(int userId) throws AirlineException {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_BOOKINGS_OF_USER)) {
            ps.setInt(1, userId);
            return readBookings(ps);
        } catch (SQLException e) {
            throw fail("Could not load bookings", e);
        }
    }

    @Override
    public Booking cancel(String pnr, int userId) throws AirlineException {
        String code = Rules.requireText(pnr, "PNR").toUpperCase(Locale.ROOT);
        try (Connection c = db.getConnection()) {
            try {
                c.setAutoCommit(false);
                int bookingId;
                int flightId;
                String status;
                try (PreparedStatement ps = c.prepareStatement(SQL_FIND_BOOKING)) {
                    ps.setString(1, code);
                    ps.setInt(2, userId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            throw new AirlineException("No booking with PNR " + code + " was found for your account.");
                        }
                        bookingId = rs.getInt("booking_id");
                        flightId = rs.getInt("flight_id");
                        status = rs.getString("status");
                    }
                }
                if (!Rules.CONFIRMED.equals(status)) {
                    throw new AirlineException("Booking " + code + " is already cancelled.");
                }
                try (PreparedStatement ps = c.prepareStatement(SQL_CANCEL_BOOKING)) {
                    ps.setInt(1, bookingId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = c.prepareStatement(SQL_SEATS_PLUS)) {
                    ps.setInt(1, flightId);
                    ps.executeUpdate();
                }
                Booking booking = loadBooking(c, bookingId);
                c.commit();
                return booking;
            } catch (AirlineException | SQLException | RuntimeException e) {
                rollbackQuietly(c);
                throw e;
            }
        } catch (SQLException e) {
            throw fail("Cancellation failed", e);
        }
    }

    // --------------------------------------------------------------- admin

    @Override
    public List<Flight> allFlights() throws AirlineException {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_ALL_FLIGHTS)) {
            return readFlights(ps);
        } catch (SQLException e) {
            throw fail("Could not load flights", e);
        }
    }

    @Override
    public Flight addFlight(Flight flight) throws AirlineException {
        Rules.validateFlight(flight);
        try (Connection c = db.getConnection();
             PreparedStatement ps = c.prepareStatement(SQL_INSERT_FLIGHT, Statement.RETURN_GENERATED_KEYS)) {
            bindFlight(ps, flight, flight.getTotalSeats());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                Flight saved = flight.copy();
                saved.setId(keys.getInt(1));
                saved.setAvailableSeats(flight.getTotalSeats());
                return saved;
            }
        } catch (SQLException e) {
            throw fail("Could not add the flight", e);
        }
    }

    @Override
    public void updateFlight(Flight flight) throws AirlineException {
        Rules.validateFlight(flight);
        try (Connection c = db.getConnection()) {
            int confirmed;
            try (PreparedStatement ps = c.prepareStatement(SQL_CONFIRMED_COUNT)) {
                ps.setInt(1, flight.getId());
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    confirmed = rs.getInt(1);
                }
            }
            if (flight.getTotalSeats() < confirmed) {
                throw new AirlineException("Total seats cannot be less than the " + confirmed
                        + " seats already booked.");
            }
            try (PreparedStatement ps = c.prepareStatement(SQL_UPDATE_FLIGHT)) {
                ps.setString(1, flight.getFlightNumber());
                ps.setString(2, flight.getSource());
                ps.setString(3, flight.getDestination());
                ps.setDate(4, Date.valueOf(flight.getTravelDate()));
                ps.setTime(5, Time.valueOf(flight.getDepartureTime()));
                ps.setTime(6, Time.valueOf(flight.getArrivalTime()));
                ps.setInt(7, flight.getTotalSeats());
                ps.setInt(8, flight.getTotalSeats() - confirmed);
                ps.setDouble(9, flight.getPrice());
                ps.setInt(10, flight.getId());
                if (ps.executeUpdate() != 1) {
                    throw new AirlineException("This flight no longer exists.");
                }
            }
        } catch (SQLException e) {
            throw fail("Could not update the flight", e);
        }
    }

    @Override
    public void deleteFlight(int flightId) throws AirlineException {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_DELETE_FLIGHT)) {
            ps.setInt(1, flightId);
            if (ps.executeUpdate() != 1) {
                throw new AirlineException("This flight no longer exists.");
            }
        } catch (SQLException e) {
            if (isConstraintViolation(e)) {
                throw new AirlineException("This flight has bookings and cannot be deleted.", e);
            }
            throw fail("Could not delete the flight", e);
        }
    }

    @Override
    public List<Booking> allBookings() throws AirlineException {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_ALL_BOOKINGS)) {
            return readBookings(ps);
        } catch (SQLException e) {
            throw fail("Could not load bookings", e);
        }
    }

    // ------------------------------------------------------------- helpers

    private Flight lockFlight(Connection c, int flightId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(SQL_LOCK_FLIGHT)) {
            ps.setInt(1, flightId);
            List<Flight> list = readFlights(ps);
            return list.isEmpty() ? null : list.get(0);
        }
    }

    private Set<Integer> takenSeats(Connection c, int flightId) throws SQLException {
        Set<Integer> taken = new HashSet<>();
        try (PreparedStatement ps = c.prepareStatement(SQL_TAKEN_SEATS)) {
            ps.setInt(1, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    taken.add(rs.getInt(1));
                }
            }
        }
        return taken;
    }

    private String uniquePnr(Connection c) throws SQLException, AirlineException {
        for (int attempt = 0; attempt < 10; attempt++) {
            String pnr = Rules.newPnr();
            if (count(c, SQL_PNR_EXISTS, pnr) == 0) {
                return pnr;
            }
        }
        throw new AirlineException("Could not generate a unique PNR. Please try again.");
    }

    private Booking loadBooking(Connection c, int bookingId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(SQL_BOOKING_BY_ID)) {
            ps.setInt(1, bookingId);
            return readBookings(ps).get(0);
        }
    }

    private void bindFlight(PreparedStatement ps, Flight f, int availableSeats) throws SQLException {
        ps.setString(1, f.getFlightNumber());
        ps.setString(2, f.getSource());
        ps.setString(3, f.getDestination());
        ps.setDate(4, Date.valueOf(f.getTravelDate()));
        ps.setTime(5, Time.valueOf(f.getDepartureTime()));
        ps.setTime(6, Time.valueOf(f.getArrivalTime()));
        ps.setInt(7, f.getTotalSeats());
        ps.setInt(8, availableSeats);
        ps.setDouble(9, f.getPrice());
    }

    private List<Flight> readFlights(PreparedStatement ps) throws SQLException {
        List<Flight> list = new ArrayList<>();
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Flight(
                        rs.getInt("flight_id"),
                        rs.getString("flight_number"),
                        rs.getString("source"),
                        rs.getString("destination"),
                        rs.getDate("travel_date").toLocalDate(),
                        rs.getTime("departure_time").toLocalTime(),
                        rs.getTime("arrival_time").toLocalTime(),
                        rs.getInt("total_seats"),
                        rs.getInt("available_seats"),
                        rs.getDouble("price")));
            }
        }
        return list;
    }

    private List<Booking> readBookings(PreparedStatement ps) throws SQLException {
        List<Booking> list = new ArrayList<>();
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Booking b = new Booking();
                b.setId(rs.getInt("booking_id"));
                b.setPnr(rs.getString("pnr"));
                b.setUserId(rs.getInt("user_id"));
                b.setFlightId(rs.getInt("flight_id"));
                b.setPassengerName(rs.getString("passenger_name"));
                b.setPassengerAge(rs.getInt("passenger_age"));
                b.setPassengerGender(rs.getString("passenger_gender"));
                b.setSeatNumber(rs.getInt("seat_number"));
                b.setBookingDate(rs.getDate("booking_date").toLocalDate());
                b.setStatus(rs.getString("status"));
                b.setFlightNumber(rs.getString("flight_number"));
                b.setSource(rs.getString("source"));
                b.setDestination(rs.getString("destination"));
                b.setTravelDate(rs.getDate("travel_date").toLocalDate());
                b.setPrice(rs.getDouble("price"));
                b.setUserEmail(rs.getString("email"));
                b.setPaymentMethod(rs.getString("payment_method"));
                b.setPaymentRef(rs.getString("payment_ref"));
                b.setTransactionId(rs.getString("txn_id"));
                b.setPaymentStatus(rs.getString("payment_status"));
                list.add(b);
            }
        }
        return list;
    }

    private static void rollbackQuietly(Connection c) {
        try {
            c.rollback();
        } catch (SQLException ignored) {
            // nothing more can be done
        }
    }

    private static boolean isConstraintViolation(SQLException e) {
        String state = e.getSQLState();
        return state != null && state.startsWith("23");
    }

    private static AirlineException connectionProblem(SQLException e) {
        String msg = String.valueOf(e.getMessage());
        if (msg.contains("No suitable driver")) {
            return new AirlineException("The MySQL JDBC driver was not found. Put mysql-connector-j-*.jar "
                    + "in the lib folder and start the program again.", e);
        }
        return new AirlineException("Cannot connect to MySQL. Check that the MySQL server is running and that "
                + "config/db.properties has the right user and password.\n\nDetails: " + msg, e);
    }

    private static AirlineException fail(String what, SQLException e) {
        String msg = String.valueOf(e.getMessage());
        if (msg.contains("No suitable driver") || msg.contains("Communications link failure")
                || msg.contains("Access denied")) {
            return connectionProblem(e);
        }
        return new AirlineException(what + ": " + msg, e);
    }
}
