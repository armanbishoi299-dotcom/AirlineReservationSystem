package airline.data;

import airline.AirlineException;
import airline.model.Flight;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Business rules and input validation shared by every data source
 * (MySQL through JDBC, and the in-memory demo store).
 */
public final class Rules {
    public static final String CONFIRMED = "Confirmed";
    public static final String CANCELLED = "Cancelled";

    public static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH);
    public static final DateTimeFormatter DATE_SHOW = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH);
    public static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm", Locale.ENGLISH);

    // no 0/O or 1/I so a PNR is easy to read out loud
    private static final String PNR_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final int PNR_LENGTH = 8;
    private static final SecureRandom RANDOM = new SecureRandom();

    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PHONE = Pattern.compile("^[0-9]{10}$");

    private Rules() { }

    /** Generates a random 8-character booking reference (PNR). */
    public static String newPnr() {
        StringBuilder sb = new StringBuilder(PNR_LENGTH);
        for (int i = 0; i < PNR_LENGTH; i++) {
            sb.append(PNR_ALPHABET.charAt(RANDOM.nextInt(PNR_ALPHABET.length())));
        }
        return sb.toString();
    }

    /** Lowest seat number (1..total) that is not taken, or -1 when the flight is full. */
    public static int nextFreeSeat(Set<Integer> taken, int totalSeats) {
        for (int seat = 1; seat <= totalSeats; seat++) {
            if (!taken.contains(seat)) {
                return seat;
            }
        }
        return -1;
    }

    // ------------------------------------------------------------ validation

    public static String requireText(String value, String field) throws AirlineException {
        if (value == null || value.trim().isEmpty()) {
            throw new AirlineException(field + " is required.");
        }
        return value.trim();
    }

    public static String normalizeEmail(String email) throws AirlineException {
        String e = requireText(email, "Email").toLowerCase(Locale.ROOT);
        if (!EMAIL.matcher(e).matches()) {
            throw new AirlineException("Please enter a valid email address.");
        }
        return e;
    }

    public static void validateRegistration(String name, String email, String password, String phone)
            throws AirlineException {
        requireText(name, "Name");
        normalizeEmail(email);
        if (password == null || password.length() < 4) {
            throw new AirlineException("Password must be at least 4 characters.");
        }
        if (phone == null || !PHONE.matcher(phone.trim()).matches()) {
            throw new AirlineException("Phone number must have exactly 10 digits.");
        }
    }

    public static LocalDate parseDate(String text, String field) throws AirlineException {
        String t = requireText(text, field);
        try {
            return LocalDate.parse(t, DATE_FMT);
        } catch (DateTimeParseException ex) {
            throw new AirlineException(field + " must be in the format yyyy-MM-dd (for example 2026-12-25).");
        }
    }

    public static LocalTime parseTime(String text, String field) throws AirlineException {
        String t = requireText(text, field);
        try {
            return LocalTime.parse(t, TIME_FMT);
        } catch (DateTimeParseException ex) {
            throw new AirlineException(field + " must be in the format HH:mm (for example 14:30).");
        }
    }

    public static int parseInt(String text, String field, int min, int max) throws AirlineException {
        String t = requireText(text, field);
        try {
            int v = Integer.parseInt(t);
            if (v < min || v > max) {
                throw new AirlineException(field + " must be between " + min + " and " + max + ".");
            }
            return v;
        } catch (NumberFormatException ex) {
            throw new AirlineException(field + " must be a whole number.");
        }
    }

    public static double parsePrice(String text) throws AirlineException {
        String t = requireText(text, "Fare");
        try {
            double v = Double.parseDouble(t);
            if (v <= 0 || v > 1_000_000) {
                throw new AirlineException("Fare must be greater than 0.");
            }
            return v;
        } catch (NumberFormatException ex) {
            throw new AirlineException("Fare must be a number.");
        }
    }

    public static void validatePassenger(String name, int age, String gender) throws AirlineException {
        requireText(name, "Passenger name");
        if (age < 1 || age > 120) {
            throw new AirlineException("Passenger age must be between 1 and 120.");
        }
        requireText(gender, "Gender");
    }

    /** Checks and cleans the fields of a flight entered by the administrator. */
    public static void validateFlight(Flight f) throws AirlineException {
        f.setFlightNumber(requireText(f.getFlightNumber(), "Flight number").toUpperCase(Locale.ROOT));
        f.setSource(requireText(f.getSource(), "Source"));
        f.setDestination(requireText(f.getDestination(), "Destination"));
        if (f.getSource().equalsIgnoreCase(f.getDestination())) {
            throw new AirlineException("Source and destination must be different.");
        }
        if (f.getTravelDate() == null || f.getDepartureTime() == null || f.getArrivalTime() == null) {
            throw new AirlineException("Date, departure time and arrival time are required.");
        }
        if (f.getTotalSeats() < 1 || f.getTotalSeats() > 500) {
            throw new AirlineException("Total seats must be between 1 and 500.");
        }
        if (f.getPrice() <= 0) {
            throw new AirlineException("Fare must be greater than 0.");
        }
    }
}
