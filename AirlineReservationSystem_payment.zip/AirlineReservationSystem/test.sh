#!/bin/sh
# Runs the automated tests.   ./test.sh          -> demo store
#                             ./test.sh mysql    -> your MySQL database (same checks)
cd "$(dirname "$0")"
[ -f test-out/airline/RepositoryTest.class ] || ./build.sh || exit 1
java -cp "out:test-out:lib/*" airline.RepositoryTest "$@"
