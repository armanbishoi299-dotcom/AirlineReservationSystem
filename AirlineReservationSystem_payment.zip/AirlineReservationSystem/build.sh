#!/bin/sh
# Compiles the program (needs a JDK, Java 8 or newer)
cd "$(dirname "$0")"
rm -rf out test-out
mkdir -p out test-out
javac --release 8 -Xlint:-options -d out $(find src -name '*.java') || exit 1
javac --release 8 -Xlint:-options -cp out -d test-out $(find test -name '*.java') || exit 1
echo "Build finished."
