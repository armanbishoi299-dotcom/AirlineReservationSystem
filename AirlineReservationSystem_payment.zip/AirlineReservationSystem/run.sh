#!/bin/sh
# Starts the program with MySQL (put mysql-connector-j-*.jar in the lib folder first)
cd "$(dirname "$0")"
[ -f out/airline/Main.class ] || ./build.sh || exit 1
java -cp "out:lib/*" airline.Main "$@"
