#!/bin/sh
# Starts the program in DEMO MODE: no MySQL needed, data is kept in memory
cd "$(dirname "$0")"
[ -f out/airline/Main.class ] || ./build.sh || exit 1
java -cp "out:lib/*" airline.Main --demo
