@echo off
rem Starts the program in DEMO MODE: no MySQL needed, data is kept in memory
cd /d "%~dp0"
if not exist out\airline\Main.class call build.bat
java -cp "out;lib/*" airline.Main --demo
